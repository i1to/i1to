#include "tcp_ser.h"
#include "daemonize.h"


typedef struct sockaddr *(SA);
struct message {
    int type;
    int length;
    char data[128];
};

char *m_strtoupper(char *s)
{
    if(NULL == s)
    {
	return s;
    }
    while(*s != '\0')
    {
	if(*s >= 'a' && *s <= 'z')
	{
	    *s -= 32;
	}
	s++;
    }
    return s;
}

int do_ser(void)
{
    daemonize();
  
    int listfd = socket(AF_INET,SOCK_STREAM,0);
    if(-1 == listfd)
    {
	perror("socket");
	exit(1);
    }

    struct sockaddr_in ser,cli;
    bzero(&ser,sizeof(ser));
    bzero(&cli,sizeof(cli));
    ser.sin_family = AF_INET;
    ser.sin_port = htons(50000);
    ser.sin_addr.s_addr = INADDR_ANY;

    int ret = bind(listfd,(SA)&ser,sizeof(ser));
    if(-1 == ret)
    {
	perror("bind");
	exit(1);
    }

    listen(listfd,3);
    int len = sizeof(cli);
    int conn = accept(listfd,(SA)&cli,&len);
    if(-1 == conn)
    {
	perror("accept");
	exit(1);
    }
    printf("new cli conn,ip:%s port:%d\n",inet_ntoa(cli.sin_addr),ntohs(cli.sin_port));
    while(1)
    {
	struct message msg = {0};
	int rd_ret = recv(conn, &msg, sizeof(msg),0);
	if(rd_ret <= 0)
	{
	    break;
	}

	if (msg.type == 1)
	{
	   printf("str msg:%s\n", msg.data);	
//	   m_strtoupper(msg.data);
	}
	else
	{
	    printf("num msg:%d\n",*msg.data);
	}
	send(conn,&msg,sizeof(msg),0);
    }

    close(listfd);
    close(conn);
    return 0;
}
