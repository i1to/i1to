#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include "list.h"


List *creat_list(CMP cmp, PRINT print,FREE free)
{
    List *temp = malloc(sizeof(List));
    if(NULL == temp)
    {
	perror("malloc");
	exit(1);
    }

    bzero(temp,sizeof(List));
    temp->head = NULL;
    temp->compare = cmp;
    temp->print = print;
    temp->free = free;

    return temp;
}

int is_empty(List *list)
{
    if(list->head == NULL)
    {
	return 1;
    }
    else
    {
	return 0;
    }
}


int insert_list(List *list,void* data)
{
    Node *temp = malloc(sizeof(Node));
    if(NULL == temp)
    {
	perror("malloc");
	exit(1);
    }

    memset(temp, 0, sizeof(Node));

    if (list->head)
    {
	temp->next = list->head;
	list->head->pre = temp;
	list->head = temp;
	temp->data = data;
    }
    else
    {
	temp->data = data;
	temp->pre = NULL;
	temp->next = NULL;
	list->head = temp;
    }

    return 0;
}


void show_list(List *list)
{
    Node *temp = list->head;

    while(temp)
    {
	(list->print)(temp->data);
	temp = temp->next;
    }

    printf("\n");
}


Node *find_list(List *list,void *data)
{
    if(is_empty(list))
    {
	printf("empty link\n");
	return NULL;
    }

    Node *p = list->head;

    while(p)
    {
	if(0 == (list->compare)(p->data, data))
	{
	    return p;
	}
	p = p->next;
    }

    return NULL;
}


int delete_list(List *list,void *data)
{
    if(is_empty(list))
    {
	printf("empty list\n");
	return -1;
    }

    Node *temp = find_list(list,data);
    if(NULL == temp)
    {
	return 0;
    }

    if(temp->pre == NULL)
    {
	list->head = temp->next;
	if(list->head)
	    list->head->pre = NULL;
	temp->next = NULL;
	list->free(temp->data);
	free(temp);
    }
    else if(temp->next == NULL )
    {
	temp->pre->next = NULL;
	list->free(temp->data);
	free(temp);
    }
    else
    {
	temp->pre->next=temp->next;
	temp->next->pre=temp->pre;
	list->free(temp->data);
	free(temp);
    }

    return -1;
}
