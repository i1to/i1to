#ifndef __FUN_H_
#define __FUN_H_

typedef int (*CMP)(void *a, void*b); 
typedef int (*PRINT)(void *a);
typedef int (*FREE)(void *a);

typedef struct node
{
    struct node *pre;
    struct node *next;
    void *data;
}Node;

typedef struct list {
    Node *head;
    CMP compare;
    PRINT print;
    FREE free;
}List;

extern List *creat_list(CMP cmp,PRINT print,FREE free);
extern int is_empty(List *list);
extern int insert_list(List *list,void *data);
extern void show_list(List *list);
extern Node *find_list(List *list,void *data);
extern int delete_list(List *list,void *data);
extern char *get_rand_str(char *buf,int len);
extern int *get_rand_num(int *buf);

#endif


