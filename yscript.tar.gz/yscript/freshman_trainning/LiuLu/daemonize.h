#ifndef __DAEMONIZE_H__
#define __DAEMONIZE_H__
int daemonize(void);
#endif /* __DAEMONIZE_H__ */
