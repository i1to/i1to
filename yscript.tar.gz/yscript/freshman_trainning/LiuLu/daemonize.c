#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void handle(int num)
{
    pid_t recycle = wait(NULL);
    printf("recycle pid:%d\n",recycle);
}

int daemonize(void)
{
    signal(SIGINT,handle);
    pid_t pid = fork();
    if(pid > 0)
    {
	exit(0);
    }
    else if(0 == pid)
    {
	setsid();
	chdir("/");
	umask(0);
	close(STDIN_FILENO);
//	close(STDOUT_FILENO);
	close(STDERR_FILENO);
	int n = 2;
	while(n--)
	{
	    printf("子进程。。PID:%d\n",getpid());   
	    sleep(1);
	}
    }
    else
    {
	perror("fork");
	exit(1);
    }
    return 0;
}


