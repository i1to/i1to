#ifndef __TCP_SER__H_
#define __TCP_SER__H_

#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/types.h>
#include <string.h>



char *m_strtoupper(char *s);
int do_ser(void);
#endif
