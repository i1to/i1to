#include <stdio.h>
#include "tcp_ser.h"
#include "tcp_cli.h"

int main(void)
{
    do_ser();
    return 0;
}
