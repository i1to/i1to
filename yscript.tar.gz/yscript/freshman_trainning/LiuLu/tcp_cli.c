#include "daemonize.h"
#include "tcp_cli.h"

typedef struct sockaddr *(SA);
struct message {
    int type;
    int length;
    char data[128];
};
char *get_rand_str(char *buf,int len)
{
    int i = 0;
    struct timeval tpstart;
    gettimeofday(&tpstart,NULL);
    srand(tpstart.tv_usec);
    char *str = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";

    for(i = 0;i < len - 1;++i )
    {
	buf[i] = str[rand()%52];
    }
    buf[len - 1] = '\0';

    return buf;
}
int send_string(int fd)
{
   struct message msg;
   msg.type = 1;

   get_rand_str(msg.data, 10);
   msg.length = 10;

   send(fd, &msg,sizeof(msg),0);

   return 0;
}

int send_int(int fd)
{
    int value = 0;
    struct message msg;
    msg.type = 2;
    struct timeval tpstart;
    gettimeofday(&tpstart,NULL);
    srand(tpstart.tv_usec);
    value =  rand()%100;
    memcpy(msg.data, &value, sizeof(value));
    msg.length = sizeof(value);

    send(fd, &msg,sizeof(msg),0);

    return 0;
}

int do_cli(void)
{

//    daemonize();
    int conn = socket(AF_INET,SOCK_STREAM,0);
    if(-1 == conn)
    {
	perror("socket");
	exit(1);
    }
    struct sockaddr_in ser;
    memset(&ser,0,sizeof(ser));
    ser.sin_family = AF_INET;
    ser.sin_port = htons(50000);
    ser.sin_addr.s_addr = inet_addr("10.71.3.11");

    int ret = connect(conn,(SA)&ser,sizeof(ser));
    if(-1 == ret)
    {
	perror("connect");
	exit(1);
    }

    while(1)
    {
	struct message msg;
	
	send_string(conn);
	int rd_ret = recv(conn,&msg,sizeof(msg),0);
	if(rd_ret < 0)
	{
	    break;
	}
	printf("cli recv str:%s\n",msg.data);
	fflush(stdout);
	sleep(1);

	send_int(conn);
	int rd_ret1 = recv(conn,&msg,sizeof(msg),0);
	if(rd_ret1 < 0)
	{
	    break;
	}
	printf("cli recv num:%d\n",*msg.data);
	fflush(stdout);
	sleep(1);
    }
    close(conn);



    return 0;
}
