#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <sys/time.h>
#include "fun.h"

#define LEN 10
#define SIZE 5

char *get_rand_str(char *buf,int len)
{
    int i = 0;
    struct timeval tpstart;
    gettimeofday(&tpstart,NULL);
    srand(tpstart.tv_usec);
    char *str = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";

    for(i = 0;i < len - 1;++i )
    {
	buf[i] = str[rand()%52];
    }
    buf[len - 1] = '\0';

    return buf;
}

int *get_rand_num(int *buf)
{
    struct timeval tpstart;
    gettimeofday(&tpstart,NULL);
    srand(tpstart.tv_usec);

    *buf = rand()%100;

    return buf;
}

int compare_str(void *a, void *b)
{
    return strcmp((char *)a, (char *)b);
}

int print_str(void *a)
{
    return printf("%s ", (char *)a);
}

int compare_int(void *a, void *b)
{
    return *(int *)a - *(int *)b;
}

int print_int(void *a)
{
    return printf("%d ", *(int *)a);
}

int Free(void *a)
{
	free(a);
}

void list_test(void)
{
    char *p = NULL;
    int i = 0;

    List *list = creat_list(compare_str, print_str,Free);

    for(i = 0; i < LEN;++i)
    {
	p = malloc(sizeof(p));
	memset(p, 0, sizeof(p));
	get_rand_str(p, SIZE);
	insert_list(list,p);
    }
    show_list(list);

    char a[10] = {0};
    for(i = 0;i < LEN;++i)
    {
	printf("input str:");
	gets(a);
	Node *b = find_list(list,a);
	delete_list(list,a);
	printf("delete : %s\n",a);
	show_list(list);
    }
    show_list(list);
}

void int_test(void)
{ 
    int *p = NULL;
    int i = 0;

    List *list = creat_list(compare_int, print_int,Free);

    for(i = 0; i < LEN;++i)
    {
	p = malloc(sizeof(p));
	memset(p, 0, sizeof(p));
	get_rand_num(p);
	insert_list(list,p);
    }
    show_list(list);
    
    int a = 0;

    for(i = 0;i < LEN;++i)
    {
	printf("input num:");
	scanf("%d",&a);	
	Node *b = find_list(list,&a);
	delete_list(list,&a);
	printf("delete : %d\n",a);
	show_list(list);
    }
}

int main()
{
//    list_test();
    int_test();

    return 0;
}
