#ifndef __TCP_CLI__H_
#define __TCP_CLI__H_
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h> 


char *get_rand_str(char *buf,int len);
int send_string(int fd);
int send_int(int fd);
int do_cli(void);

#endif
