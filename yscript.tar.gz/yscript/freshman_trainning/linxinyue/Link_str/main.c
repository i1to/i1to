#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"Link_str.c"
//#include"Link_str.h"


int main()
{ 
    char listname[20];
    char delname[20];
    int choice;
    list *head; 
    head=create(10);
    display(head);

    do{
    	   printf("\n请选择要执行的操作\n");
	   printf("*******  1 查找 *******\n");	
	   printf("*******  2 删除 *******\n");	
	   printf("*******  3 插入 *******\n");
	   printf("*******  4 显示 *******\n");
	   printf("*******  5 退出 *******\n");	
	   scanf("%d",&choice);
    
           switch(choice){
	   
	         case 1:
                          printf("请输入要查找的元素\n");
                          scanf("%s",&listname);
                          search(head,listname);
                          system("read");
			  break;
	         case 2:
			  printf("请输入要删除的元素\n");
			  scanf("%s",&delname);
			  del(head,delname);
			  system("read");
			  break;
	         case 3:			 
			  addlist(head);
			  system("read");
			  break;
			  
		 case 4:
			  display(head);
			  system("read");
			  break;
		 case 5:

                          return 0;
	   }
    }while(1);
    
}
