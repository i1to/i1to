
typedef struct node{
    char data[20];
    struct node *prior;
    struct node *next;
 }list;


extern list *create(int n);
extern void display(list *head);
extern list *search(list *head,char *x);
extern list *del(list *head,char *x);
extern list *addlist(list *head);

