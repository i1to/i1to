#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"Link_str.h"

/***************creat链表*******************/

list *create(int n){
    list *temp,*head,*s;//s是用来存新建元素的变量
    int i;

    head=(list*)malloc(sizeof(list));
    head->data[0]='\0';
    head->prior=NULL;
    head->next=NULL;
    temp=head;


    for(i=0;i<n;i++){
         
        s=(list *)malloc(sizeof(list));
        temp->next=s;
        printf("请输入第%d个字符串:  ",i+1);
        scanf("%s",&s->data);
        s->prior=temp;
        s->next=NULL;
        temp=s;
    }

    head->prior=temp;
    temp->next=head;
    return (head);
}



void display(list *head){
    int i=0;
    list *temp;//临时指针 
    temp=head->next;//从第二个结点开始 
    printf("该双向链表为\n");
    while(temp!=head){//输出到头节点之前也就是尾结点 
	i++;
        printf("*****   第%2d个结点：%2s   *****\n",i,temp->data);
        temp=temp->next;
    }
    printf("\n");
}

/*************search*********************/

list *search(list *head,char *x){
    int n=0;
    char *y;
    list * temp=head->next;
    while(temp){
        n++;
        y=temp->data;
        if(strcmp(y,x)==0){
	    printf("查找的是第%d个结点.\n",n);
	    
	    return 0;
	}
	    
	 else{
	   temp=temp->next;
	 } 

    }
    printf("没有查找到该数据！\n");
} 

/*************delete********************/


list *del(list *head,char *x){
     
     char *y;
     list *temp = head->next;
     while(temp){
          
	  y=temp->data;
	  if(strcmp(y,x)==0){
	        temp->prior->next=temp->next;
	        temp->next->prior=temp->prior;
		free(temp);
		printf("删除成功!!\n");
                display(head);
		return 0;
	  
	  }
          else {
	  temp=temp->next;
	  }  
     }
     printf("删除失败,未找到该元素！");
     return 0;

}

/**********add***********************/

list *addlist(list *head){

    int add;
    list *temp = (list*)malloc(sizeof(list));
    printf("请输入要插入的位置：");
    scanf("%d",&add);
    printf("请输入要插入的元素：");
    scanf("%s",&temp->data);

     
       
  //     temp->prior=NULL;
  //     temp->next =NULL;
       if(add==1){
	    
            temp->next=head->next;
	    head->next->prior=temp;
	    head->next=temp;
	    
       }
       else{
            int i = 0;
	    list *body=head;
	    for(i=1;i<=add-1;i++){
	       body=body->next;
	       if(body == NULL){
	           printf("插入位置有误\n");
                   break;
	       
	       }	        
	    }

	    if(body){
	            if(body->next ==NULL){
		     body->next = temp;
		     temp->prior = body;
		     display(head);
		    }
                    else{
		        body->next->prior=temp;
			temp->next=body->next;
			body->next=temp;
			temp->prior =body;
		        display(head);
		    }
		    }
	    }
          return 0;
       }
