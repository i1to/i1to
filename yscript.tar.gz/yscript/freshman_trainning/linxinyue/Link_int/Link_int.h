typedef struct line{
  struct line * prior;
  int data;
  struct line * next;
}line;

//双链表的创建函数
extern line * initLine (line * head);
//输出双链表的函数
extern void display(line * head);
//给链表插入元素的函数
extern line * addLine(line*head,int add,int data); 
//删除链表元素的函数
extern line * delLine(line * head,int data);
//查找链表元素的函数 
extern line * selectLine(line * head,int data); 
