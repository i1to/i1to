#include<stdio.h>
#include<stdlib.h>
#include"Link_int.h"


line*  initLine(line* head){
	int i = 0;
	int j = 0;
	line *list = NULL;
	//创建一个首元结点，链表的头指针为head;
	head = (line*)malloc(sizeof(line));
	//初始化
	head->prior = NULL;
	head->data = 1;
	head->next = NULL;
	
	//声明一个指向首元结点的指针，方便后期向链表中添加新创建的元素
	list = head;
	
	for(i=2;i<=9;i++){
		//创建新的结点并进行初始化
		j=rand()%100;
	        line * body = (line*)malloc(sizeof(line));
		body->prior=NULL;
		body->next = NULL;
		body->data= j;
		
		//新节点与链表最后一个节点建立连接
		list->next = body;
		body->prior = list;
		//list永远指向链表中最后一个结点
		list = list->next;		 
	} 
	return head;
}

void display(line * head){
	int i =0;
	line * temp = head->next;
	printf("该双向链表为：\n\n"); 
	while(temp){
		i++;
		printf("  第%2d个结点：%4d \n",i,temp->data);
		temp = temp->next;
	}
}

line* selectLine(line * head,int data){
	line *t = head->next;
                int i =1;
               while (t){
                   if(t->data == data){
                     printf("查找的是第%d个结点。\n",i);
                     return head;
}
                 i++;
                 t = t->next;
}
              printf("未找到该元素！");
              return head;             
}

line * delLine(line * head, int data){
               line * temp = head->next;
               while(temp){
                           if(temp->data ==data){
                              temp->prior->next =temp->next;
                             temp->next->prior= temp->prior;
                             free(temp);
                            return head;
}
                        temp = temp->next;
}
                     printf("未找到该元素！");
                    return head;
}


line *addLine(line *head,int add ,int data){
                     line * temp = (line*)malloc(sizeof(line));
                     temp->data = data;
                     temp->prior = NULL;
                     temp->next = NULL;
                    if(add == 1){
                                temp->next = head;
                               head->prior = temp;
                               head = temp;
                 
}
                      else{
                            int i = 0;
                            line * body = head;
                           for(i=1;i<=add-1;i++){
                                    body = body->next;
                                    if(body == NULL){
                                         printf("插入位置有误\n");
                                         break;
                                   }
                            }
                      if(body){
                                  if(body->next ==NULL){
                                     body->next = temp;
                                     temp->prior = body;    
            }
                     else{
                           body->next->prior = temp;
                           temp->next = body->next;
                          body->next = temp;
                           temp->prior = body;
            }
                              
}                           
}
                   return head;
}
