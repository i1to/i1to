#include<stdio.h>
#include<stdlib.h>
#include"Link_int.c"

int main(){
	int a ;
	int b ;
	int c;
	int d;
	int choice;
	//创建头指针
	line * head = NULL; 
	//调用链表创建函数
	head = initLine(head);
	//输出已经创建好的链表
	display(head);
	
	do {
	   printf("\n请选择要执行的操作\n");
	   printf("*******  1 查找 *******\n");	
	   printf("*******  2 删除 *******\n");	
	   printf("*******  3 插入 *******\n");	
	   printf("*******  4 退出 *******\n");	
	   scanf("%d",&choice);
	switch(choice){
		
		case 1 :
		printf("请输入要查找的元素：");
		scanf("%d",&a);
		selectLine(head,a);
		display(head);
		system("read");
		break;
		
		case 2 :
		printf("请输入要删除的元素："); 
		scanf("%d",&b);
		delLine(head,b);
		display(head);
		system("read");
		break;
		
		case 3 :
		printf("请输入要插入的位置：");
		scanf("%d",&c);
		printf("请输入要插入的元素：") ;
		scanf("%d",&d);
		addLine(head,c,d);
		display(head);
		system("read");
		break;
		
		case 4 :
		return 1;
		

				 
	} 
	}while(1);
}
