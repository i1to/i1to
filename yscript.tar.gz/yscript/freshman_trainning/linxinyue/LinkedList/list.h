typedef int (*CmpFunc)(void *a, void*b); 
typedef int (*PrintFunc)(void *a);

typedef struct node
{
    struct node *prior;
    struct node *next;
    void *data;
}Node;

typedef struct list {
    Node *head;
    CmpFunc compare;
}List;

extern List *creat_list(CmpFunc cmp);
extern int insert_list(List *list,void *data);
extern void display(List *list,PrintFunc print);
extern Node *find_list(List *list,void *data);
extern int delete_list(List *list,void *data);
extern char *get_rand_str(char *Str);
extern int *get_rand_num(int *Str);
