 #include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include"list.h"
#include"list.c"
#define LEN 10
#define SIZE 3


int main()
{
    int option;
    int i = 0;

    printf(" 1------str \n 2------int\n 3------exit\n");
    printf("Please enter your choice: ");
    scanf("%d",&option);

    if(option==1)
    {
        char *p = NULL;
       
        List *list = creat_list(compare_str);

    for(i; i < LEN;++i)
    {
	p = malloc(sizeof(p));
	memset(p, 0, sizeof(p));
	get_rand_str(p);
	insert_list(list,p);
    }
        display(list,print_str);

        char a[10] = {0};
      
	printf("find str: ");
	scanf("%s",&a);
	Node *b = find_list(list,a);
	display(list,print_str);
	printf("delete : ");
	scanf("%s",&a);
	delete_list(list,a);
	display(list,print_str);
	
      
    }
    else if(option==2)
    {
        int *p = NULL;
  
        List *list = creat_list(compare_int);

    for(i; i < LEN;++i)
    {
	p = malloc(sizeof(p)); 
	memset(p, 0, sizeof(p));
	get_rand_num(p);
	insert_list(list,p);
    }
        display(list,print_int);
        
	int a;
	printf("find num:\n");
	scanf("%d",&a);	
	Node *b = find_list(list,&a);
	display(list,print_int);
	printf("delete : \n");
	scanf("%d",&a);
	delete_list(list,&a);
	display(list,print_int);
	
    }
    else if(option==3)
    {
    return 0;
    }
}
