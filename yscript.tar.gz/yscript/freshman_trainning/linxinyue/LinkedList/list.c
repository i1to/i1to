#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#define LEN 10
#define SIZE 3


List *creat_list(CmpFunc cmp)
{
    List *temp = NULL;
    temp = malloc(sizeof(List));
        
    temp->head = NULL;
    temp->compare = cmp;

    return temp;
}


int insert_list(List *list,void* data)
{
    Node *temp = malloc(sizeof(Node));
    if(temp == NULL)
    {
	return -1;
    }

    temp->data=0;
    temp->next=NULL;
    temp->prior =NULL;

    if (list->head != 0)
    {
	temp->next = list->head;
	list->head->prior = temp;
	list->head = temp;
	temp->data = data;
    }
    else
    {
	temp->data = data;
	temp->prior = NULL;
	temp->next = NULL;
	list->head = temp;
    }

    return 0;
}


void display(List *list,PrintFunc print)
{
    Node *temp = list->head;

    while(temp)
    {
	print(temp->data);
	temp = temp->next;
    }
    printf("\n\n");
}


Node *find_list(List *list,void *data)
{
       Node *p = list->head;

    while(p)
    {
	if(0 == (list->compare)(p->data, data))
	{
	    printf("Successfully found the element.\n");
	    return p;
	}
	p = p->next;
    }
    printf("Find failed.\n");
    return NULL;
}


int delete_list(List *list,void *data)
{
    Node *temp = find_list(list,data);
    if(temp == NULL)
    {
	return 0;
    }

    if(temp->prior == NULL)
    {
	list->head = temp->next;
	if(list->head)
	list->head->prior = NULL;
	temp->next = NULL;
	printf("Successfully deleted the element.\n");
	free(temp);
	return 0;
    }
    else if(temp->next == NULL )
    {
	temp->prior->next = NULL;
	printf("Successfully deleted the element.\n");
	free(temp);
	return 0;
    }
    else
    {
	temp->prior->next=temp->next;
	temp->next->prior=temp->prior;
	printf("Successfully deleted the element.\n"); 
	free(temp);
	return 0;
    }
    
    
    printf("failed to delete.\n");      

    return 0;
}


char *get_rand_str(char *Str)
{
    int i = 0;
    char *str = "abcdefghigklmnopqrstuvwxyzQWERTYUIOPLKJHGFDSAZXCVBNM";
    int size = SIZE;
    for(i;i < size ;++i )
    {
	Str[i] = str[rand()%52];
    }

    return Str;
}

int *get_rand_num(int *num)
{
    
    *num = rand()%100;

    return num;
}


int compare_str(void *a, void *b)
{
    return strcmp((char *)a, (char *)b);
}

int print_str(void *a)
{
    return printf("%s ", (char *)a);
}

int compare_int(void *a, void *b)
{
    return *(int *)a - *(int *)b;
}

int print_int(void *a)
{
    printf("%2d ",*(int*)a);
    return 0;
}

