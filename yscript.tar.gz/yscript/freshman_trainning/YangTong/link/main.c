#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include "link.h"
//Structure data type

typedef  struct mixdata 
{
    int a ;
    char b[10];
    char *c;

}DATA;

void df(void *data)
{
    DATA *Data=(DATA *)data;
    if(NULL == Data)
    {
	return;
    }	 
    free(Data->c);
    return;
}

int random_str(char* random_str, const int random_len)
{
    int i, random_num, seed_str_len;
    struct timeval tv;
    unsigned int seed_num;
    char seed_str[] = "abcdefghijklmnopqrstuvwxyz"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; //随机字符串的随机字符集

    seed_str_len = strlen(seed_str);
    
    gettimeofday(&tv, NULL);
    seed_num = (unsigned int)(tv.tv_sec + tv.tv_usec);
    srand(seed_num);

    for(i = 0; i < random_len; i++)
    {
        random_num = rand()%seed_str_len;
        random_str[i] = seed_str[random_num];
    }
    random_str[random_len]='\0';
    return 0;
}

void  DATApt(void  * data)
{
	DATA * Data = (DATA *)data;
	if(NULL== Data)return;
	printf("string: %s - int%d\n", Data->b,Data->a);
	return;
}
 
void  sdpt(void * data)
{
	char * Data = (char *)data;
	printf("string: %s\n", Data);
	return;
}

void  ddpt(void * data)
{
	int * Data = (int*)data;
	printf("int:%d\n", * Data);
	return;
}

int  DATAcmp(void *data1,void *data2)
{
        DATA* d1 = (DATA*)data1;
        DATA* d2 = (DATA*)data2;
	return d1->a == d2->a  && strcmp(d1->b,d2->b)==0;
}

int  dcmp(void *data1,void *data2)
{
        int* d1 = (int*)data1;
        int* d2 = (int*)data2;
	return *d1 == *d2;
}

int  scmp(void *data1,void *data2)
{
    char *d1 = (char*)data1;
    char *d2 = (char*)data2;
    if(strcmp(d1,d2)==0)return 1;
    else return 0; 

}


int main(int argc, char *argv[])
{
	int i;
	int *value = NULL;
	int arr[10] = {0};
	char  *str;
	unsigned int tm = time(NULL);
	srand(tm);   


  //init   Parameter1   2            3
	// datacmpare   dataprintf   datafree
	LinkList list = Init_LinkList(dcmp,ddpt,df);
	for (i=0;i<10;i++)
	{
	    value = malloc(sizeof(int));
	    *value = rand()%1001;
	    arr[i] = *value;
	    Insert_LinkList(list,  value);
	}  

	printf("元素个数:%d\n", Length_LinkList(list));	
	Foreach_LinkList(list);

	printf("Aftre insret元素个数:%d\n", Length_LinkList(list));
	Find_LinkList(list,&arr[5]);

	for (i=0;i<10;i++)
	{
	Remove_LinkList(list,&arr[i]);
	printf("%d ok\n",i);
	}

//	Foreach_LinkList(list);
	printf("清空链表后元素个数:%d\n", Length_LinkList(list));




  //init   Parameter1   2            3
	// datacmpare   dataprintf   datafree
	LinkList slist = Init_LinkList(scmp,sdpt,df);


	for(i=0;i<10;i++)
	{
	str=(char *)malloc(sizeof(char)*10);
	random_str(str,8);
	printf("%s\n",str);
	Insert_LinkList(slist,str);
	}

	Foreach_LinkList(slist);
	Clear_LinkList(slist);
	printf("清空链表后元素个数:%d\n", Length_LinkList(list));
	
	return 0;
}



#if 0


	DATA data1 = { "apple",56 };
	DATA data2 = { "Hello",23 };

	DATA data3 = { "world",46 };
	DATA data4 = { "iaasd",36 };
	DATA data5 = { "eer",16 };
	DATA data6 = { "dppwerle",6 };
	DATA data7 = { "cellero",83 };
	DATA data8 = { "lgedf",93 };
	DATA data9 = { "nello",73 };
	DATA data10 = { "oello",43 };
	//init
	LinkList Dlist = Init_LinkList(&DATAcmp,&DATApt);

	//insert
	Insert_LinkList(Dlist,  &data1);
	Insert_LinkList(Dlist,  &data2);
	Insert_LinkList(Dlist,  &data3);
	Insert_LinkList(Dlist,  &data4);
	Insert_LinkList(Dlist,  &data5);
	Insert_LinkList(Dlist,  &data6);
	Insert_LinkList(Dlist,  &data7);
	Insert_LinkList(Dlist,  &data8);
	Insert_LinkList(Dlist,  &data9);
	Insert_LinkList(Dlist,  &data10);
	

	printf("元素个数:%d\n", Length_LinkList(Dlist));

	Insert_LinkList(Dlist,  &data10);
	Insert_LinkList(Dlist,  &data9);
	printf("Aftre insert元素个数:%d\n", Length_LinkList(Dlist));
 
	Remove_LinkList(Dlist,&data9);
	Remove_LinkList(Dlist,&data10);
	printf("Aftre remove元素个数:%d\n", Length_LinkList(Dlist));

 
//	Clear_LinkList(list); 
//	Destroy_LinkList(list);

 
	return 0;
}

#endif
