#include<stdio.h>
#include<stdlib.h>
#include"link.h"


LinkList  Init_LinkList(datacompare cmp ,dataprint dpt,datafree df)
{
	LINKLIST* plist = (LINKLIST*)malloc(sizeof(LINKLIST));
	plist->pHead = NULL;
	plist->pTail = NULL;
	plist->cmp = cmp;
	plist->dpt = dpt;
	plist->df = df;
	plist->size = 0;
	return plist;
}

//pos range 1 ~ list->size 
int Insert_LinkList(LINKLIST* linkList, void* newdata)
{	
	//if out of range 
	if (NULL == linkList|| newdata == NULL )
	{
	    return 0;
	}

    	LinkNode* newNode = (LinkNode*)malloc(sizeof(LinkNode));
    	newNode->data = newdata;
	newNode->next = NULL;
	newNode->pre = NULL;


	if(NULL == linkList->pHead) 
	{
	    linkList->pHead = newNode;
	    linkList->pTail = newNode;	
	    linkList->size++;
	}
	else 
	{
	    linkList->pTail->next = newNode;
	    newNode->pre = linkList->pTail;
	  //  newNode->next = NULL;

	    linkList->pTail = newNode;	
	    linkList->size++;

	}
	return 1;
}

int Remove_LinkList(LINKLIST* linkList, void *data)
{       
    if (NULL == linkList || NULL == data)
    {
	return 0;
    }
    LinkNode * Pre = linkList->pHead;
    LinkNode * Del = NULL;

    while(  Pre != NULL )
    {
	if(linkList->cmp(Pre->data,data))
	{
	    Del = Pre;
	    break;
	}	
	Pre = Pre->next;
    }

    //connect node 
    if(Del !=NULL)
    {
	if(Del->pre == NULL && Del->next != NULL)
	{
	      linkList->pHead = Del->next;
	      Del->next->pre = NULL;
	}
	else if(Del->next == NULL && Del->pre != NULL)
	{
            linkList->pTail = Del->pre;		
	    Del->pre->next = NULL;
	       
	}
	else if(Del->next == NULL && Del->pre == NULL)
	{
	    linkList->pHead = NULL;
	    linkList->pTail = NULL;
	}
	else
	{
	    Pre=Del->pre;
	    Pre->next = Del->next;
	    Del->next->pre = Pre;
	}


	linkList->df(Del->data);
	free(Del);
	Del = NULL;
	linkList->size--;
    }

    return 1;
}
#if 0
int Change_LinkList(LINKLIST* linkList, int pos, void* newdata)
{	int i;
	//
	if (NULL == pList || NULL == newdata)
	{
	    return 0;
	}
	//
	if (pos<1 || pos>linkList->size)
	{
	    pos = linkList->size + 1;
	}
	LinkNode * changeNode = linkList->pHead;
	//
	for ( i = 1; i < pos; i++)
	{
	    changeNode =  changeNode->next;
	}
	//
	LinkNode* newNode = (LinkNode*)malloc(sizeof(LinkNode));

	newNode->data = newdata;

	changeNode->next->pre = newNode;
	changeNode->pre->next = newNode;
	newNode->next = changeNode->next;
	newNode->pre = changeNode->pre;

	free(changeNode);

	return 1;
}
#endif
int Clear_LinkList(LINKLIST* linkList)
{	
	if (NULL == linkList)
	{
		return 0;
	}
	LinkNode * clean = linkList->pHead;
	LinkNode * Next=clean->next;
	while ( Next != NULL)
	{
		
	    linkList->df(clean->data);
	    free(clean);
	    clean = Next;
	    Next=Next->next;
	}
	linkList->size = 0;
	return 1;
}

#if 0
int Destroy_LinkList(LINKLIST* linkList)
{
	if (NULL == linkList)
	{
		return 0;
	}
	Clear_LinkList(linkList);
	free(linkList->pHead);
	linkList->pHead = NULL;
	return 1;
}
#endif


int Length_LinkList(LINKLIST* linkList)
{
	if (NULL == linkList)
	{
		return -1;
	}
	return linkList->size;
}

int Foreach_LinkList(LINKLIST* linkList)
{	
	if (NULL == linkList )
	{
		return 0;
	}
	LinkNode* cur = linkList->pHead;

	if(NULL == cur)
	    return 0;

	while (cur != NULL)
	{
		linkList->dpt(cur->data);
		cur = cur->next;
	}
	return 1;
}


int Find_LinkList(LINKLIST* linkList,void * data)
{	
        int i=1;
	if (NULL == linkList )
	{
		return 0;
	}
	LinkNode* find = linkList->pHead;
	while (find->next != NULL)
	{
		if(linkList->cmp(find->data,data))
		{
		    printf("The element you are looking for is in %d line\n",i);
		    break;
		}
		i++;
		find = find->next;
	}
	if(find->next == NULL)
	{
	printf("\ncould not find it\n");
	}
	return 1;
}

 
