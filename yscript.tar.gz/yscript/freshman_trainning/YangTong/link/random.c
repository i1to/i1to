#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>

int get_random_str(char* random_str, const int random_len)
{
    int i, random_num, seed_str_len;
    struct timeval tv;
    unsigned int seed_num;
    char seed_str[] = "abcdefghijklmnopqrstuvwxyz"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; //随机字符串的随机字符集

    seed_str_len = strlen(seed_str);
    
    gettimeofday(&tv, NULL);
    seed_num = (unsigned int)(tv.tv_sec + tv.tv_usec); //超了unsigned int的范围也无所谓，我们要的只是不同的种子数字
    srand(seed_num);

    for(i = 0; i < random_len; i++)
    {
        random_num = rand()%seed_str_len;
        random_str[i] = seed_str[random_num];
    }

    return 0;
}

int main(int argc, char* argv[])
{
    char str[10];
 
    get_random_str(str, 8);
    printf("str %s\n", str);
    get_random_str(str, 8);
    printf("str %s\n", str);
    get_random_str(str, 8);
    printf("str %s\n", str);
    get_random_str(str, 8);
    printf("str %s\n", str);
    get_random_str(str, 8);
    printf("str %s\n", str);

    return 0;
}


