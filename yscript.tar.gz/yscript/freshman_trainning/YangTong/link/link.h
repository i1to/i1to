#ifndef __LINK_H__
#define __LINK_H__

//Double Link list node
typedef int(*datacompare)(void *data1,void *data2);
typedef void(*dataprint)(void * data);
typedef void(*datafree)(void *data);


typedef struct link
{
    struct link * pre;
    struct link * next;
    void * data;
  }LinkNode;

typedef struct linklist
{
    LinkNode * pHead;
    LinkNode * pTail;
    datacompare cmp;
    dataprint dpt;
    datafree df;
    int size;
}LINKLIST;

typedef void* LinkList;

LinkList  Init_LinkList(datacompare cmp ,dataprint dpt,datafree df);

int Insert_LinkList(LINKLIST* linkList, void* newdata);

int InsertByValue_LinkList(LINKLIST* linkList, void* data);

int Remove_LinkList(LINKLIST* linkList, void *data);

int Clear_LinkList(LINKLIST* linkList);

//int Destroy_LinkList(LINKLIST* linkList);

int Length_LinkList(LINKLIST* linkList);

//int Clear_LinkList(LINKLIST* plist);

int Foreach_LinkList(LINKLIST* linkList);

int Find_LinkList(LINKLIST* linkList,void * data);


#endif
