/*
 *<LeftMouse>
 *The linux source code uses a multi-level time wheel

 *5 levels of time wheel are adopted, and the granularity 
 *of each level of time wheel are: 1ms, 256ms, 256*64ms,
 *256*64*64ms, 256*64*64*64ms.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>
#include "list.h"
#include "log.h"

#define TVN_BITS        6                  
#define TVR_BITS        8
#define TVN_SIZE        (1<<TVN_BITS)   // 0000 0000 0100 0000  64
#define TVR_SIZE        (1<<TVR_BITS)   // 0000 0001 0000 0000  256
#define TVN_MASK        (TVN_SIZE - 1)//   0000 0000 0011 1111   63
#define TVR_MASK        (TVR_SIZE - 1)//   0000 0000 1111 1111   255
 
struct tvec_base;

#define INDEX(N) ((ba->current_index >> (TVR_BITS + (N) * TVN_BITS)) & TVN_MASK)
 
typedef void (*timeouthandle)(unsigned long);
 
struct timer_list{
    struct list_head entry;          // timer_link entry| Time connected as a linked list
    unsigned long expires;           // timeout_time
    void (*function)(unsigned long); // timeout_callback_function
    unsigned long data;              // timeout function parameter
    struct tvec_base *base;          // ->timewheel
};
 
struct tvec 
{
    struct list_head vec[TVN_SIZE];//64_lattice
};
 
struct tvec_root
{
    struct list_head vec[TVR_SIZE];//256 lattice
};
 
struct tvec_base
{
    unsigned long       current_index; // overtime time
    pthread_t           thincrejiffies;
    pthread_t           threadID;
    struct tvec_root    tv1; //0~2^8 (1)           Precision 1
    struct tvec         tv2; // ~2^8*2^6 (2)       Precision 256
    struct tvec         tv3; // ~2^8*2^6*2 (3)     Precision 256*64
    struct tvec         tv4; // ~2^8*2^6*3 (4)     Precision 256*64*64
    struct tvec         tv5; // ~2^8*2^6*4-1 (5)   Precision           :ms
};
 
static void internal_add_timer(struct tvec_base *base, struct timer_list *timer)
{
    struct list_head *vec;
    unsigned long expires = timer->expires;
    unsigned long idx = expires - base->current_index;

#if 1
    if( (signed long)idx < 0 ) 
    {
        vec = base->tv1.vec + (base->current_index & TVR_MASK);//
    }
    else if ( idx < TVR_SIZE )                  /*level 1 timewheel*/
    {
        int i = expires & TVR_MASK;
        vec = base->tv1.vec + i;
    }
    else if( idx < 1 << (TVR_BITS + TVN_BITS) )   /*2*/
    {
        int i = (expires >> TVR_BITS) & TVN_MASK;
        vec = base->tv2.vec + i;
    }
    else if( idx < 1 << (TVR_BITS + 2 * TVN_BITS) )/*3*/
    {
        int i = (expires >> (TVR_BITS + TVN_BITS)) & TVN_MASK;
        vec = base->tv3.vec + i;
    }
    else if( idx < 1 << (TVR_BITS + 3 * TVN_BITS) )/*4*/
    {
        int i = (expires >> (TVR_BITS + 2 * TVN_BITS)) & TVN_MASK;
        vec = base->tv4.vec + i;		 
    }
    else                                           /*5*/                                               
    {
        int i;
        if (idx > 0xffffffffUL)
        {
            idx = 0xffffffffUL;
            expires = idx + base->current_index;
        }
        i = (expires >> (TVR_BITS + 3 * TVN_BITS)) & TVN_MASK;
        vec = base->tv5.vec + i;
    }
#else

#endif  /*optimization*/
    list_add_tail(&timer->entry, vec);
}
 
static inline void 
detach_timer(struct timer_list *timer)
{
    struct list_head *entry = &timer->entry;
    __list_del(entry->prev, entry->next);
    entry->next = NULL;
    entry->prev = NULL;
}
 
static int 
__mod_timer(struct timer_list *timer, unsigned long expires)
{        
    if(NULL != timer->entry.next)
        detach_timer(timer);
   
    internal_add_timer(timer->base, timer);
    return 0;
}
 
//Modify the timeout period  API
int mod_timer(void *ptimer, unsigned long expires)
{
    struct timer_list *timer  = (struct timer_list *)ptimer;
    struct tvec_base *base;
     
    base = timer->base;
    if(NULL == base)
    {
	return -1;
    }  
    expires = expires + base->current_index;    
    if(timer->entry.next != NULL  && timer->expires == expires)
    { 
	return 0;
    }
    if( NULL == timer->function )
    {
        errlog("timer's timeout function is null\n");
        return -1;
    }
   
    timer->expires = expires;
    return __mod_timer(timer,expires);
}
 
//add_timer
static void __ti_add_timer(struct timer_list *timer)
{
    if( NULL != timer->entry.next )
    {
        errlog("timer is already exist\n");
        return;
    }
    mod_timer(timer, timer->expires);            
}
 
/*
 *ADD timer API
 *return : timer
 * */
void* ti_add_timer(void *ptimewheel, unsigned long expires,timeouthandle phandle, unsigned long arg)
{
    struct timer_list  *ptimer;
 
    ptimer = (struct timer_list *)malloc( sizeof(struct timer_list) );
    if(NULL == ptimer)
        return NULL;
 
    bzero( ptimer,sizeof(struct timer_list) );        
    ptimer->entry.next = NULL;
    ptimer->base = (struct tvec_base *)ptimewheel;
    ptimer->expires = expires;
    ptimer->function  = phandle;
    ptimer->data = arg;
 
    __ti_add_timer(ptimer);
 
    return ptimer;
}
 
/*
 *delete timer API
 *re : void
 * */
void ti_del_timer(void *p)
{
    struct timer_list *ptimer =(struct timer_list*)p;
 
    if(NULL == ptimer)
        return;
 
    if(NULL != ptimer->entry.next)
        detach_timer(ptimer);
    free(ptimer);
}

/*timewheel cascade*/
static int cascade(struct tvec_base *base, struct tvec *tv, int index)
{
    struct list_head *pos,*tmp;
    struct timer_list *timer;
    struct list_head tv_list;
   
    list_replace_init(tv->vec + index, &tv_list);/*tv_list / tv->vec + index*/
    list_for_each_safe(pos, tmp, &tv_list)/*Traverse tv_list*/
    {
        timer = list_entry(pos,struct timer_list,entry);
	internal_add_timer(base, timer);
    }
    return index;
}
 
static void *deal_function_timeout(void *base)
{
    struct timer_list *timer;
    int ret;
    struct timeval tv;
    struct tvec_base *ba = (struct tvec_base *)base;
   
    for(;;)
    {
        gettimeofday(&tv, NULL);  
        while( ba->current_index <= (tv.tv_sec*1000 + tv.tv_usec/1000) )/*ms*/
        {        
           struct list_head work_list;
           int index = ba->current_index & TVR_MASK;/**/
           struct list_head *head = &work_list;
           /**/
           if(!index && (!cascade(ba, &ba->tv2, INDEX(0))) &&( !cascade(ba, &ba->tv3, INDEX(1))) && (!cascade(ba, &ba->tv4, INDEX(2))) )
               cascade(ba, &ba->tv5, INDEX(3));
           
            ba->current_index ++;
            list_replace_init(ba->tv1.vec + index, &work_list);
            while(!list_empty(head))
            {
                void (*fn)(unsigned long);
                unsigned long data;
                timer = list_first_entry(head, struct timer_list, entry);
                fn = timer->function;
                data = timer->data;
                detach_timer(timer);
                (*fn)(data);  
            }
        }
    }
}
 
static void init_tvr_list(struct tvec_root * tvr)
{
    int i;
    for( i = 0; i<TVR_SIZE; i++ )
        INIT_LIST_HEAD(&tvr->vec[i]);
}
 
static void init_tvn_list(struct tvec * tvn)
{
    int i;
    for( i = 0; i<TVN_SIZE; i++ )
        INIT_LIST_HEAD(&tvn->vec[i]);
}
 
//create_timewheel API
void *ti_timewheel_create(void )
{
    struct tvec_base *base;
    int ret = 0;
    struct timeval tv;
 
    base = (struct tvec_base *) malloc( sizeof(struct tvec_base) );
    if( NULL==base )
        return NULL;
   
    bzero( base,sizeof(struct tvec_base) );
       
    init_tvr_list(&base->tv1);
    init_tvn_list(&base->tv2);
    init_tvn_list(&base->tv3);
    init_tvn_list(&base->tv4);
    init_tvn_list(&base->tv5);
   
    gettimeofday(&tv, NULL);
    base->current_index = tv.tv_sec*1000 + tv.tv_usec/1000;/*Current time: milliseconds*/
 
    if( 0 != pthread_create(&base->threadID,NULL,deal_function_timeout,base) )
    {
        free(base);
        return NULL;
    }    
    return base;
}
 
static void ti_release_tvr(struct tvec_root *pvr)
{
    int i;
    struct list_head *pos,*tmp;
    struct timer_list *pen;
 
    for(i = 0; i < TVR_SIZE; i++)
    {
        list_for_each_safe(pos,tmp,&pvr->vec[i])
        {
            pen = list_entry(pos,struct timer_list, entry);
            list_del(pos);
            free(pen);
        }
    }
}
 
static void ti_release_tvn(struct tvec *pvn)
{
    int i;
    struct list_head *pos,*tmp;
    struct timer_list *pen;
 
    for(i = 0; i < TVN_SIZE; i++)
    {
        list_for_each_safe(pos,tmp,&pvn->vec[i])
        {
            pen = list_entry(pos,struct timer_list, entry);
            list_del(pos);
            free(pen);
        }
    }
}
 
/*
 *release_timewheel API
 * */
void ti_timewheel_release(void * pwheel)
{  
    struct tvec_base *base = (struct tvec_base *)pwheel;
   
    if(NULL == base)
    {
	return;
    }
    ti_release_tvr(&base->tv1);
    ti_release_tvn(&base->tv2);
    ti_release_tvn(&base->tv3);
    ti_release_tvn(&base->tv4);
    ti_release_tvn(&base->tv5);
 
    free(pwheel);
}
 
/************demo****************/
struct request_para
{
    void *timer;
    int val;
};
 
void mytimer(unsigned long arg)
{
    struct request_para *para = (struct request_para *)arg;
 
    log("%d\n",para->val);
    mod_timer(para->timer,1000);  //timer relood :ms
 
    sleep(1);/*block*/
 
    //timer_release
    //ti_del_timer(para->timer);
}
 
int main(int argc,char *argv[])
{
    void *pwheel = NULL;
    void *timer  = NULL;
    struct request_para *para;
   
 
    para = (struct request_para *)malloc( sizeof(struct request_para) );
    if(NULL == para)
        return 0;
    bzero(para,sizeof(struct request_para));
 
    //add  timewheel
    pwheel = ti_timewheel_create();
    if(NULL == pwheel)
    {    
	return -1;
    }
    //add timer
    para->val = 100;
    para->timer = ti_add_timer(pwheel, 1000, &mytimer, (unsigned long)para);
   
    while(1)
    {
        sleep(10);
    }
 
    ti_timewheel_release(pwheel);
   
    return 0;
}

