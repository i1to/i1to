#include <stddef.h>
#include <stdlib.h>
#include <sys/time.h>
#include "Timer.h"

//Get reference time
static uint32 GetJiffies_old(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

static uint32 GetJiffies(void)
{
    struct timespec ts;  //  :ns（10 ^ -9 ）
    //atention :When using the clock_gettime function, some systems may need to connect to the rt library and add the -lrt parameter.
    clock_gettime(CLOCK_MONOTONIC, &ts);  /* CLOCK_MONOTONIC means to start timing from the moment the system is started, 
                                               and is not affected by the system time being changed by the user*/
    return (ts.tv_sec * 1000 + ts.tv_nsec / 1000000);  // Returns the time in milliseconds
}

static void ListTimerInsert(struct LIST_TIMER *pNew, struct LIST_TIMER *pPrev, struct LIST_TIMER *pNext)
{
    pNext->pPrev = pNew;
    pNew->pNext = pNext;
    pNew->pPrev = pPrev;
    pPrev->pNext = pNew;
}

static void ListTimerInsertHead(struct LIST_TIMER *pNew, struct LIST_TIMER *pHead)
{
    ListTimerInsert(pNew, pHead, pHead->pNext);
}

static void ListTimerInsertTail(struct LIST_TIMER *pNew, struct LIST_TIMER *pHead)
{
    ListTimerInsert(pNew, pHead->pPrev, pHead);
}

/*<LeftMouse>
 *Use the new node pNew to replace the position of pOld in the doubly cyclically linked list.
 *If there is only one node pOld in the doubly linked list, after replacing it with pNew, 
 *there is also only one node pNew.
 *
 * */ 
static void ListTimerReplace(struct LIST_TIMER *pOld, struct LIST_TIMER *pNew)
{
    pNew->pNext = pOld->pNext;
    pNew->pNext->pPrev = pNew;
    pNew->pPrev = pOld->pPrev;
    pNew->pPrev->pNext = pNew;
}

/*Use the new node pNew to replace the position of pOld in the doubly cyclically linked list.
 * */
static void ListTimerReplaceInit(struct LIST_TIMER *pOld, struct LIST_TIMER *pNew)
{
    ListTimerReplace(pOld, pNew);
    pOld->pNext = pOld;
    pOld->pPrev = pOld;
}

/*
 *After initialization, the doubly linked list in each tick has only one head node
 * */ 
static void InitArrayListTimer(struct LIST_TIMER *arrListTimer, uint32 nSize)
{
    uint32 i;
    for(i=0; i<nSize; i++)
    {
        arrListTimer[i].pPrev = &arrListTimer[i];
        arrListTimer[i].pNext = &arrListTimer[i];
    }
}

static void DeleteArrayListTimer(struct LIST_TIMER *arrListTimer, uint32 uSize)
{
    struct LIST_TIMER listTmr, *pListTimer;
    struct TIMER_NODE *pTmr;
    uint32 idx;

    for(idx=0; idx<uSize; idx++)
    {
        ListTimerReplaceInit(&arrListTimer[idx], &listTmr);
        pListTimer = listTmr.pNext;
        while(pListTimer != &listTmr)
        {
            pTmr = (struct TIMER_NODE *)((uint8 *)pListTimer - offsetof(struct TIMER_NODE, ltTimer));
            pListTimer = pListTimer->pNext;
            free(pTmr);
        }
    }
}

/*<LeftMouse>
 *Calculate the time wheel and the tick on the time wheel according to the end time of the timer, 
 *and then insert the new timer node into the end of the two-way circular linked list of the tick
 *
 * */
static void AddTimer(LPTIMERMANAGER lpTimerManager, LPTIMERNODE pTmr)
{
    struct LIST_TIMER *pHead;
    uint32 i, uDueTime, uExpires;

    uExpires = pTmr->uExpires; // Timer expiration time
    uDueTime = uExpires - lpTimerManager->uJiffies;
    if (uDueTime < TVR_SIZE)   // idx < 256 (2^8)
    {
        i = uExpires & TVR_MASK; // expires & 255
        pHead = &lpTimerManager->arrListTimer1[i];
    }
    else if (uDueTime < 1 << (TVR_BITS + TVN_BITS)) // idx < 16384 (2^14)
    {
        i = (uExpires >> TVR_BITS) & TVN_MASK;      // i = (expires>>8) & 63
        pHead = &lpTimerManager->arrListTimer2[i];
    }
    else if (uDueTime < 1 << (TVR_BITS + 2 * TVN_BITS)) // idx < 1048576 (2^20)
    {
        i = (uExpires >> (TVR_BITS + TVN_BITS)) & TVN_MASK; // i = (expires>>14) & 63
        pHead = &lpTimerManager->arrListTimer3[i];
    }
    else if (uDueTime < 1 << (TVR_BITS + 3 * TVN_BITS)) // idx < 67108864 (2^26)
    {
        i = (uExpires >> (TVR_BITS + 2 * TVN_BITS)) & TVN_MASK; // i = (expires>>20) & 63
        pHead = &lpTimerManager->arrListTimer4[i];
    }
    else if ((signed long) uDueTime < 0)
    {
        /*
         * Can happen if you add a timer with expires == jiffies,
         * or you set a timer to go off in the past
         */
        pHead = &lpTimerManager->arrListTimer1[(lpTimerManager->uJiffies & TVR_MASK)];
    }
    else
    {
        /* If the timeout is larger than 0xffffffff on 64-bit
         * architectures then we use the maximum timeout:
         */
        if (uDueTime > 0xffffffffUL)
        {
            uDueTime = 0xffffffffUL;
            uExpires = uDueTime + lpTimerManager->uJiffies;
        }
        i = (uExpires >> (TVR_BITS + 3 * TVN_BITS)) & TVN_MASK; // i = (expires>>26) & 63
        pHead = &lpTimerManager->arrListTimer5[i];
    }
    ListTimerInsertTail(&pTmr->ltTimer, pHead);
}

/* Traverse the two-way circular linked list of the time wheel arrlistTimer, 
 * and add the timers in it to the specified time wheel according to the expiration time
 * */static uint32 CascadeTimer(LPTIMERMANAGER lpTimerManager, struct LIST_TIMER *arrListTimer, uint32 idx)
{
    struct LIST_TIMER listTmr, *pListTimer;
    struct TIMER_NODE *pTmr;

    ListTimerReplaceInit(&arrListTimer[idx], &listTmr);
    pListTimer = listTmr.pNext;
    while(pListTimer != &listTmr)
    {
        /*/ Calculate the address of the structure struct TIMER_NODE according to the pointer
	address of the member ltTimer of the structure struct TIMER_NODE and the offset of the 
	member in the structure*/
	pTmr = (struct TIMER_NODE *)((uint8 *)pListTimer - offsetof(struct TIMER_NODE, ltTimer));
        pListTimer = pListTimer->pNext;
        AddTimer(lpTimerManager, pTmr);
    }
    return idx;
}

static void RunTimer(LPTIMERMANAGER lpTimerManager)
{
#define INDEX(N) ((lpTimerManager->uJiffies >> (TVR_BITS + (N) * TVN_BITS)) & TVN_MASK)
    uint32 idx, uJiffies;
    struct LIST_TIMER listTmrExpire, *pListTmrExpire;
    struct TIMER_NODE *pTmr;

    if(NULL == lpTimerManager)
        return;
    uJiffies = GetJiffies();
    pthread_mutex_lock(&lpTimerManager->lock);
    while(TIME_AFTER_EQ(uJiffies, lpTimerManager->uJiffies))
    {
        idx = lpTimerManager->uJiffies & TVR_MASK;
        if (!idx &&
                (!CascadeTimer(lpTimerManager, lpTimerManager->arrListTimer2, INDEX(0))) &&
                (!CascadeTimer(lpTimerManager, lpTimerManager->arrListTimer3, INDEX(1))) &&
                !CascadeTimer(lpTimerManager, lpTimerManager->arrListTimer4, INDEX(2)))
            CascadeTimer(lpTimerManager, lpTimerManager->arrListTimer5, INDEX(3));
        pListTmrExpire = &listTmrExpire;
        /* After the new node pListTmrExpire replaces arrListTimer1[idx], 
	/ the two-way circular linked list arrListTimer1[idx] has only its own node.
	/ pListTmrExpire becomes the entrance to the doubly circular linked list*/
	ListTimerReplaceInit(&lpTimerManager->arrListTimer1[idx], pListTmrExpire);
        /*Traverse the two-way circular linked list of the time wheel arrListTimer1,
	 * and execute the callback functions of all timers in the linked list*/
	pListTmrExpire = pListTmrExpire->pNext;
        while(pListTmrExpire != &listTmrExpire)
        {
            pTmr = (struct TIMER_NODE *)((uint8 *)pListTmrExpire - offsetof(struct TIMER_NODE, ltTimer));
            pListTmrExpire = pListTmrExpire->pNext;
            pTmr->timerFn(pTmr->pParam);
            //
            if( 0 == pTmr->uPeriod )
            {
            	free(pTmr);
	    }
	    else if ( 1 == pTmr->uPeriod)
	    {
		pTmr->uExpires = lpTimerManager->uJiffies + pTmr->uPertime;
		AddTimer(lpTimerManager, pTmr);
	    }
            else 
	    {
	    	pTmr->uExpires = lpTimerManager->uJiffies + pTmr->uPeriod;
                AddTimer(lpTimerManager, pTmr);
	    }
        }
        lpTimerManager->uJiffies++;
    }
    pthread_mutex_unlock(&lpTimerManager->lock);
}

// <LeftMouse>Timer thread. Time in 1 millisecond unit
static void *ThreadRunTimer(void *pParam)
{
    LPTIMERMANAGER pTimerMgr;

    pTimerMgr = (LPTIMERMANAGER)pParam;
    if(pTimerMgr == NULL)
        return NULL;
    while(!pTimerMgr->uExitFlag)
    {
        RunTimer(pTimerMgr);
        SleepMilliseconds(1);  // Thread sleeps for 1 millisecond
    }
    return NULL;
}

void SleepMilliseconds(uint32 uMs)
{
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = uMs * 1000;  // tv.tv_usec Unit: microsecond
    select(0, NULL, NULL, NULL, &tv);
}

/*
 * Create a timer manager
 * re : struct - LPTIMERMANAGER lpTimerMgr
 */
LPTIMERMANAGER CreateTimerManager(void)
{
    LPTIMERMANAGER lpTimerMgr = (LPTIMERMANAGER)malloc(sizeof(TIMERMANAGER));
    if(lpTimerMgr != NULL)
    {
        lpTimerMgr->thread = (pthread_t)0;
        lpTimerMgr->uExitFlag = 0;
        pthread_mutex_init(&lpTimerMgr->lock, NULL);
        lpTimerMgr->uJiffies = GetJiffies();
        InitArrayListTimer(lpTimerMgr->arrListTimer1, sizeof(lpTimerMgr->arrListTimer1)/sizeof(lpTimerMgr->arrListTimer1[0]));
        InitArrayListTimer(lpTimerMgr->arrListTimer2, sizeof(lpTimerMgr->arrListTimer2)/sizeof(lpTimerMgr->arrListTimer2[0]));
        InitArrayListTimer(lpTimerMgr->arrListTimer3, sizeof(lpTimerMgr->arrListTimer3)/sizeof(lpTimerMgr->arrListTimer3[0]));
        InitArrayListTimer(lpTimerMgr->arrListTimer4, sizeof(lpTimerMgr->arrListTimer4)/sizeof(lpTimerMgr->arrListTimer4[0]));
        InitArrayListTimer(lpTimerMgr->arrListTimer5, sizeof(lpTimerMgr->arrListTimer5)/sizeof(lpTimerMgr->arrListTimer5[0]));
        lpTimerMgr->thread = ThreadCreate(ThreadRunTimer, lpTimerMgr);
    }
    return lpTimerMgr;
}

// Delete timer manager
void DestroyTimerManager(LPTIMERMANAGER lpTimerManager)
{
    if(NULL == lpTimerManager)
        return;
    lpTimerManager->uExitFlag = 1;
    if((pthread_t)0 != lpTimerManager->thread)
    {
        ThreadJoin(lpTimerManager->thread);
        ThreadDestroy(lpTimerManager->thread);
        lpTimerManager->thread = (pthread_t)0;
    }
    DeleteArrayListTimer(lpTimerManager->arrListTimer1, sizeof(lpTimerManager->arrListTimer1)/sizeof(lpTimerManager->arrListTimer1[0]));
    DeleteArrayListTimer(lpTimerManager->arrListTimer2, sizeof(lpTimerManager->arrListTimer2)/sizeof(lpTimerManager->arrListTimer2[0]));
    DeleteArrayListTimer(lpTimerManager->arrListTimer3, sizeof(lpTimerManager->arrListTimer3)/sizeof(lpTimerManager->arrListTimer3[0]));
    DeleteArrayListTimer(lpTimerManager->arrListTimer4, sizeof(lpTimerManager->arrListTimer4)/sizeof(lpTimerManager->arrListTimer4[0]));
    DeleteArrayListTimer(lpTimerManager->arrListTimer5, sizeof(lpTimerManager->arrListTimer5)/sizeof(lpTimerManager->arrListTimer5[0]));
    pthread_mutex_destroy(&lpTimerManager->lock);
    free(lpTimerManager);
}


/*Create a timer. API
 *fnTimer Callback function address.
 *pParam The parameter of the callback function.
 *uDueTime The timeout interval for the first trigger.
 *uPeriod timer cycle period, if it is 0, the timer will only run once.
 *return  struct- LPTIMERNODE pTmr 
 */
LPTIMERNODE create_timer(LPTIMERMANAGER lpTimerManager, uint32 uPeriod, uint32 uDueTime, void (*timerFn)(void*), void *pParam)
{
    LPTIMERNODE pTmr = NULL;
    if(NULL == timerFn || NULL == lpTimerManager)
        return NULL;
    pTmr = (LPTIMERNODE)malloc(sizeof(TIMERNODE));
    if(pTmr != NULL)
    {
        pTmr->uPeriod = uPeriod;
	pTmr->uPertime = uDueTime;
        pTmr->timerFn = timerFn;
        pTmr->pParam = pParam;

        pthread_mutex_lock(&lpTimerManager->lock);
        pTmr->uExpires = lpTimerManager->uJiffies + uDueTime;
        AddTimer(lpTimerManager, pTmr);
        pthread_mutex_unlock(&lpTimerManager->lock);
    }
    return pTmr;
}

//Delete a timer.
int32 delete_timer(LPTIMERMANAGER lpTimerManager, LPTIMERNODE lpTimer)
{
    struct LIST_TIMER *pListTmr;
    if(NULL != lpTimerManager && NULL != lpTimer)
    {
        pthread_mutex_lock(&lpTimerManager->lock);
        pListTmr = &lpTimer->ltTimer;
        pListTmr->pPrev->pNext = pListTmr->pNext;
        pListTmr->pNext->pPrev = pListTmr->pPrev;
        free(lpTimer);
        pthread_mutex_unlock(&lpTimerManager->lock);
        return 0;
    }
    else
        return -1;
}

LPTIMERNODE modify_timer(LPTIMERMANAGER lpTimerManager,LPTIMERNODE lpTimer, uint32 uInterval, void (*callback)(void*), void *pData)
{
    if(NULL == lpTimer || NULL == lpTimerManager || NULL == callback)
    {
	return NULL;
    }
    LPTIMERNODE pTmr = lpTimer;
    if(pTmr != NULL)
    {
	pTmr->timerFn = callback;
	pTmr->pParam = pData;
	pTmr->uPertime = uInterval;
        pthread_mutex_lock(&lpTimerManager->lock);
	pTmr->uExpires = lpTimerManager->uJiffies + uInterval;
        AddTimer(lpTimerManager, pTmr);
        pthread_mutex_unlock(&lpTimerManager->lock);
    }
    return pTmr;
}

