#include <stdio.h>
#include "Timer.h"

void TimerFun2(void *pParam)
{
    LPTIMERMANAGER pManager;
    pManager = (LPTIMERMANAGER)pParam;
    printf("timer_fun2:Timer expire! Jiffies: %lu\n", pManager->uJiffies);
}


void TimerFun1(void *pParam)
{
    LPTIMERMANAGER pManager;
    pManager = (LPTIMERMANAGER)pParam;
    printf("timer_fun1:Timer expire! jiffies: %lu\n", pManager->uJiffies);
}


int main(void)
{
    LPTIMERMANAGER pManager;

    LPTIMERNODE pTimer2;
    LPTIMERNODE pTimer1;

    pManager = CreateTimerManager();
/* user space
 * int create_timer(LPTIMERMANAGER pManager, int interval, int con, 
 *                           void* data, void (*callback)(void *data))
 * int delete_timer(LPTIMERMANAGER pManager,LPTIMERNODE pTimer)；
 *  SleepMilliseconds(2001);//:ms
 */

    //create_timer(pManager, 1000, 6000, TimerFun, pManager );
    pTimer2 = create_timer(pManager, 0 , 100000, TimerFun2, pManager);
   // pTimer1 = create_timer(pManager, 1 , 500, TimerFun1, pManager);

 SleepMilliseconds(5001);//:ms

modify_timer( pManager,pTimer2 , 500 ,TimerFun1, pManager);
 
 //SleepMilliseconds(5001);//:ms

//modify_timer( pManager,pTimer2 , 2000 ,TimerFun2, pManager);

    SleepMilliseconds(10001);//:ms
    
    SleepMilliseconds(100001);//:ms

    delete_timer(pManager, pTimer2);
    // delete_timer(pManager, pTimer1);

    //SleepMilliseconds(3000);




/*  */
    DestroyTimerManager(pManager);
    return 0;
}
