#ifndef _DEF_H_
#define _DEF_H_

//
typedef char int8;
typedef unsigned char uint8;
typedef uint8 byte;
typedef short int16;
typedef unsigned short uint16;
typedef long int32;
typedef unsigned long uint32;

#endif //_DEF_H_
