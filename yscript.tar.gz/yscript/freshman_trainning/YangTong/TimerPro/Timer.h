#ifndef _TIMER_H_
#define _TIMER_H_

#include "def.h"
#include "Thread.h"

#define CONFIG_BASE_SMALL 0    // TVN_SIZE=64  TVR_SIZE=256
#define TVN_BITS (CONFIG_BASE_SMALL ? 4 : 6)
#define TVR_BITS (CONFIG_BASE_SMALL ? 6 : 8)
#define TVN_SIZE (1 << TVN_BITS)
#define TVR_SIZE (1 << TVR_BITS)
#define TVN_MASK (TVN_SIZE - 1)
#define TVR_MASK (TVR_SIZE - 1)
#define MAX_TVAL ((unsigned long)((1ULL << (TVR_BITS + 4*TVN_BITS)) - 1))

#define TIME_AFTER(a,b) ((long)(b) - (long)(a) < 0)
#define TIME_BEFORE(a,b) TIME_AFTER(b,a)
#define TIME_AFTER_EQ(a,b) ((long)(a) - (long)(b) >= 0)
#define TIME_BEFORE_EQ(a,b) TIME_AFTER_EQ(b,a)

typedef struct LIST_TIMER
{
    struct LIST_TIMER *pPrev;
    struct LIST_TIMER *pNext;
} LISTTIMER, *LPLISTTIMER;

typedef struct TIMER_NODE
{
    struct LIST_TIMER ltTimer;  // linked list entry
    uint32 uExpires;            // expiration time
    uint32 uPeriod;             //  The duration of the re-triggering interval.if(== 0)Run once
    uint32 uPertime;            //  to store Restart cycle again Intervals
    void (*timerFn)(void *);    // Callback : The starting address of the running function.
    void *pParam;               // Function parameters
} TIMERNODE, *LPTIMERNODE;

typedef struct TIMER_MANAGER
{
    pthread_mutex_t lock;       // Sync lock
    pthread_t thread;           // Identifier : Pointer to the thread.
    uint32 uExitFlag;           // Thread exit flag(0:Continue, other: Exit)
    uint32 uJiffies;            // Base time (current time), unit: milliseconds
    struct LIST_TIMER arrListTimer1[TVR_SIZE];  // 1  Timer with precision:0 ~ 255 milliseconds。tick: 1  ms
    struct LIST_TIMER arrListTimer2[TVN_SIZE];  // 2  256 ~ 256*64-1                             tick  256 
    struct LIST_TIMER arrListTimer3[TVN_SIZE];  // 3  256*64 ~ 256*64*64-1                       tick  256*64 
    struct LIST_TIMER arrListTimer4[TVN_SIZE];  // 4  256*64*64 ~ 256*64*64*64-1                 tick  256*64*64 
    struct LIST_TIMER arrListTimer5[TVN_SIZE];  // 5  256*64*64*64 ~ 256*64*64*64*64-1           tick  256*64*64*64
} TIMERMANAGER, *LPTIMERMANAGER;

void SleepMilliseconds(uint32 uMs);

LPTIMERMANAGER CreateTimerManager(void);

void DestroyTimerManager(LPTIMERMANAGER lpTimerManager);

LPTIMERNODE create_timer(LPTIMERMANAGER lpTimerManager, uint32 uPeriod, uint32 uDueTime,void (*timerFn)(void*), void *pParam);

LPTIMERNODE modify_timer(LPTIMERMANAGER lpTimerManager,LPTIMERNODE lpTimer, uint32 uInterval, void (*callback)(void*), void *pData);

int32 delete_timer(LPTIMERMANAGER lpTimerManager, LPTIMERNODE lpTimer);

#endif //_TIMER_H_
