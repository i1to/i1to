#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <pthread.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>


#define SERVER_IP "127.0.0.1"       // for lucal communication
//#define SERVER_IP "10.71.3.24" // for internet communication
#define SERVER_PORT     18888
#define RUNNING_DIR	"/tmp"
#define FILE_PATH       "/tmp/deamon2.txt"
#define LOG_NAME        "deamon2_syslog"


typedef struct data
{
    int type;
    int len;
    char data[128];
}data_info;

void * thread_receive(void *fd);
void daemonize();
int send_str (int fd);
int random_str(char* random_str, const int random_len);
int send_int (int fd);


int main()
{
    //daemonize();	
    int socket_fd = -1;
    struct sockaddr_in server_addr;	
    int ret=0,sign=0;
    pthread_t thread;

    socket_fd = socket(AF_INET,SOCK_STREAM,0);
    if(socket_fd < 0)
    {
	perror("socket err");
	exit(-1);
    }
    memset(&server_addr,0,sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);	
    ret = connect(socket_fd,(struct sockaddr *)&server_addr,sizeof(struct sockaddr));
    if(ret < 0)
    {
	perror("connect err");
	return -1;    
    }
    printf("connect OK\n");
    pthread_create(&thread,NULL,thread_receive,&socket_fd);


    while(1)
    {
	printf("choose:1;2\n");
        scanf("%d",&sign);
      	if(sign == 1)
	{
	   send_str(socket_fd);
	}
	if(sign== 2)
	{
	    send_int(socket_fd);
	}
    }	
    close(socket_fd);
    return 0;
}

void * thread_receive(void *fd)
{
    //char str_recv[30] = {'0'};
    int socket_fd = *((int *)fd);
    int ret = 0;
    struct data buffer;

    while(1)
    {
        memset(&buffer,'0',sizeof(buffer));
	ret = recv(socket_fd,&buffer,sizeof(buffer),0);
        if(ret > 0)
        {
	    printf("recv :");
        }
	if(buffer.type == 1)
	{
	    printf("%s\n",buffer.data);
	}
	if(buffer.type == 2)
	{
	    printf("%d\n",*(int*)buffer.data);
	}
        sleep(1);
    }
   // free(buffer);
    return NULL;
}

int send_str (int fd)
{
    struct data buffer;
    buffer.type=1;
    random_str (buffer.data,8);
    buffer.len = 8;
    send (fd,&buffer,sizeof(buffer),0);
    return 0; 
}


int send_int (int fd)
{
    struct data buffer;
    buffer.type = 2; 
    int value = 0;
    time_t t;
    srand((unsigned)time(&t));
    value = rand()%1001;
    memcpy (buffer.data,&value,sizeof(value));
    printf("%d,\n",value);
    buffer.len = sizeof(value);
    send(fd ,&buffer ,sizeof(buffer),0);
    return 0;
}

int random_str(char* random_str, const int random_len)
{
    int i, random_num, seed_str_len;
    struct timeval tv;
    unsigned int seed_num;
    char seed_str[] = "abcdefghijklmnopqrstuvwxyz"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; 

    seed_str_len = strlen(seed_str);
    
    gettimeofday(&tv, NULL);
    seed_num = (unsigned int)(tv.tv_sec + tv.tv_usec);
    srand(seed_num);

    for(i = 0; i < random_len; i++)
    {
        random_num = rand()%seed_str_len;
        random_str[i] = seed_str[random_num];
    }
    random_str[random_len]='\0';
    return 0;
}
#if 0
void daemonize()
{
    pid_t pid=0;
    pid_t ret=0;
    //int i=0,num=0;
    pid=fork();	
    if (-1 == pid) 
    {    
	perror("fork err");
	return ;
    }    
    if (pid>0) 
    {
	printf("pid=%d\n",pid);
        exit(0); /*1 parent process exit*/
    }	
    openlog(LOG_NAME,LOG_PID,LOG_DAEMON);
    /* child (daemon) continues */
    ret = setsid(); /* obtain a new process group */
    if(ret < 0)
    {
	perror("setsid");
	syslog(LOG_ERR,"%s\n","setside");
	exit(1);
    }

    if(chdir(RUNNING_DIR)<0) /* change running directory */
    {
	syslog(LOG_ERR,"%s\n","chdir");
	exit(1);
    }
    umask(0); /*set newly created file permissions
		Cancel any file permission block*/
    num = getdtablesize();
    for (;i<num;i--)
    {
	close(i);
    }
}
#endif 
