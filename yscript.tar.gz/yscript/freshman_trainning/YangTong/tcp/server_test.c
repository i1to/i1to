#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <pthread.h>
#include <signal.h>

#define SERVER_IP "127.0.0.1"       // for lucal communication
// #define SERVER_IP "10.71.3.24"" // for net communication
#define SERVER_PORT     18888
#define RUNNING_DIR	"/tmp"
#define FILE_PATH       "./deamon1.txt"
#define LOG_NAME        "deamon1_syslog"

typedef struct information
{
    int socket_fd;
    char * ipaddr;
    uint16_t port;
}socket_info;


typedef struct data
{
    int type;
    int len;
    char data[128];
}data_info;

struct information cli_num[10];
int cli_count=0;

int check_thread(pthread_t thread);
void * thread_receive(void * info);
void * thread_accept(void * listen_fd);
void daemon_create(void);
int net_init(void);
char * strupr(char *str);

int main()
{
    //daemon_create();
    int listen_fd = 0;
      pthread_t tid  = 0;
	int connect_fd = 0;
	socket_info info;
	struct sockaddr_in client_addr;
	int size = sizeof(client_addr);
      //  pthread_t tid;
	int ret;

    listen_fd = net_init();
    if (listen_fd < 0)
    {
        perror("net_init err");
        return -1;
    }
    pthread_create(&tid,NULL,thread_accept,&listen_fd);	   
    while(1) 
    {
	connect_fd = accept(listen_fd,(struct sockaddr *)(&client_addr),(socklen_t *)(&size));
	if(connect_fd <0)
	{
	    perror("Accept err");
	    continue;
	}   
	printf("connect ok\n");

	char str_helo[20] = {"CONFIRM_MSG:hello"};
	send(connect_fd,str_helo,20,0);   

	info.socket_fd = connect_fd;
	info.ipaddr = inet_ntoa(client_addr.sin_addr);
	info.port = client_addr.sin_port;
	cli_num[cli_count] = info;
	cli_count++;

	ret = pthread_create(&tid,NULL,thread_accept,&info);
	if (ret != 0)
	{
	    perror("pthread");
	    close(connect_fd);
	    continue;
	}
	sleep(1);	
    }	    
    pthread_join(tid,NULL);
    close(listen_fd);
    return 0;	
}

void * thread_accept(void * info)
{
    int sign,i,j;
    socket_info _info = *((socket_info *)info);
    struct data buffer;

    while(1)
    {
	memset(&buffer,'0',sizeof(buffer));
	sign = recv (_info.socket_fd,&buffer,sizeof(buffer),0);
	if(sign == 0)
	{
	    for(j = 0; j < cli_count; j++)
	    {
                if(cli_num[j].socket_fd == _info.socket_fd)
		{
                    break;
		}
            }
            for(i = j; i < cli_count-1; i++)
            {
                cli_num[i] = cli_num[i+1];
            }
	}
	else
	{
	    if (buffer.type == 1)
	    {
	    printf("recv%s:%d::%s\n",_info.ipaddr, _info.port, buffer.data);	
	    }
	
	    if (buffer.type == 2)
	    {
	    printf("recv%s:%d::%d\n",_info.ipaddr,_info.port,*(int *)buffer.data);
	    }
	}
	sleep(1);
    }
    pthread_exit(0);
    return NULL;
}	

char * strupr(char *str)
{
    char *p =str;
    while(*p !='\0') 
    {
	if(*p >='a'&&*p <='z')
	{
	   *p-=32;
	}
	p++;			
    }
    return p;
} 	

int net_init(void)
{
    int listen_fd = -1;
    struct sockaddr_in server_addr;	
    int ret=0;
    listen_fd = socket(AF_INET,SOCK_STREAM,0);
    if(listen_fd < 0)
    {
	perror("socket err");
	return listen_fd;
    }
    memset(&server_addr,0,sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);	
    ret = bind(listen_fd,(struct sockaddr *)&server_addr,sizeof(server_addr));
    if(ret<0 )
    {
	perror("bind err");
	close(listen_fd);
	listen_fd = -1;
	return listen_fd;
    }
    ret = listen(listen_fd,5);
    if(ret < 0 )
    {
	close(listen_fd);
	listen_fd = -1;
	return listen_fd;
    }
    printf("init OK lsten...\n");
    return listen_fd; 
}

void daemon_create(void)
{
    pid_t pid=0;
    pid_t ret=0;
    //int i=0,num=0;	
    pid=fork();	
    if (-1 == pid) 
    {    
	perror("fork err");
	return ;
    }    
    if (pid>0) 
    {
	printf("pid=%d\n",pid);
	exit(0); /*1 parent process exit*/
    }	
    openlog(LOG_NAME,LOG_PID,LOG_DAEMON);
    /* child (daemon) continues */
    ret = setsid(); /* obtain a new process group */
    if(ret < 0)
    {
	//perror("setsid");
	syslog(LOG_ERR,"%s\n","setside");
	exit(1);
    }
    printf("deamon OK");
}
#if 0
    if(chdir(RUNNING_DIR)<0) /* change running directory */
    {
	syslog(LOG_ERR,"%s\n","chdir");
	exit(1);
    }
    umask(0); /* set newly created file permissions
    Cancel any file permission block*/
    num = getdtablesize();
    for (;i<num;i--)
    {
	close(i);
    }

#endif


