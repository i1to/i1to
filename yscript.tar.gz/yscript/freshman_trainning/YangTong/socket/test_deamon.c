#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
//#include <syslog.h>

#define RUNNING_DIR	"/tmp"
#define FILE_PATH       "./daemon1.txt"
//#define LOG_NAME        "deamon_syslog"

void daemonize()
{
        pid_t pid=0;
	pid_t ret=0;
	int i=0,num=0;
	
	pid=fork();	
	if (-1 == pid) 
	{    
	    perror("fork err");
	    return ;
	}    
	if (pid>0) 
	{
	    exit(0); //1 parent process exit/
	}
	
	//openlog(LOG_NAME,LOG_PID|LOG_CONS,LOG_DAEMON);
	    // child (daemon) continues /
	ret = setsid(); // obtain a new process group /
	if(ret < 0)
	{
	    //perror("setsid");
	    //syslog(LOG_ERR,"%s\n","setside");
	    exit(1);
	}
#if 0
	if(chdir(RUNNING_DIR)<0) // change running directory /
	{
	    //syslog(LOG_ERR,"%s\n","chdir");
	    exit(1);
	}

	umask(0); // set newly created file permissions
	             //Cancel any file permission block
	num = getdtablesize();
	for (;i<num;i--)
	{
	    close(i);
	}
#endif
}

int main()
{
	    int fd = 0;
	    char *buff = "is working\n";
	daemonize();
	while(1) 
        {

	    fd=open(FILE_PATH,O_CREAT|O_WRONLY|O_APPEND,0600);
	    if(fd<0)
	    {
	//	syslog(LOG_ERR,"File open ERR");
		printf("open err\n");
		exit(1);
	    }
	    write(fd,buff,strlen(buff)+1);
	    close(fd);
	    sleep(1); /* run */
        }
}

/* EOF */
