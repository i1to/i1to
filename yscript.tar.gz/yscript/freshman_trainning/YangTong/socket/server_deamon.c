#include <stdio.h>
#include "tcp.h"


char * strupr(char *str)
{
    char *p =str;
    while(*p !='\0') 
    {
	if(*p >='a'&&*p <='z')
	{
	   *p-=32;
	}
	p++;			
    }
    return p;
} 

   


int main()
{
      //  daemon_create();
     	int listen_fd = 0;
	int i=0;
	//char str_send[30]={'0'};

	pthread_t tid  = 0;
	listen_fd = net_init();
	if (listen_fd < 0)
	{
	    perror("net_init err");
	    return -1;
	}

	pthread_create(&tid,NULL,thread_accept,&listen_fd);
	   
	//send(cli_num[i].socket_fd,str_helo,20,0);
	while(1) 
	{
	    if(read2send)
	    {
		//  jug pthread 
		for (i=0;i<thread_count;i++)
		{
		    if(check_thread(thread_num[i]) == 1)    
		    {
			thread_count--;
		    }
		}
		/*data operate
		 *there are users ->iterate users
		 *if cli's n'msg is int ->send int^2
		 *if char   ->send Uppercase characters
		 */

		if(cli_num <= 0)
		{
		    printf("no cli\n");
		}
		else
		{
		    for (i=0;i<cli_count;i++)
		    {


			strupr(buffer);
			send(cli_num[i].socket_fd,buffer,30,0);
			read2send = 0;

		    }
		}
	    }
	    sleep(1);
	}    
	pthread_join(tid,NULL);
	close(listen_fd);
	return 0;	
}


int check_thread(pthread_t thread)
{
    int res = 1;
    int res_kill = pthread_kill(thread,0);
    if(res_kill == 0)
    {
	res = 0;
    }
    return res;
}

void * thread_receive(void * info)
{
    int buffer_len;
    int con,i;
    bzero(&buffer,sizeof(buffer));


    socket_info _info = *((socket_info *)info);
    while(1)
    {
	buffer_len = recv (_info.socket_fd,buffer,30,0);
	if(buffer_len == 0)
	{
	    printf("%s:%d cli_close\n",_info.ipaddr,_info.port);
	    for(con = 0; con < cli_count; con++)
	    {
                if(cli_num[con].socket_fd == _info.socket_fd)
		{
                    break;
                }
            }
            for(i = con; i < cli_count-1; i++)
            {
                cli_num[i] = cli_num[i+1];
            }


	    thread_count--;
	    break;
	}
	else if(buffer_len <0)
	{
	    printf("read Fail\n");
	    break;
	}

	buffer[buffer_len] = '\0';
	printf("%s:%d:%s\n",_info.ipaddr , _info.port,buffer);
	read2send=1;
	sleep(1);
    }
    return NULL;
}	
	

void * thread_accept(void * fd)
{
    while(1) 
    {
	int listen_fd =*((int *)fd);
	int connect_fd = 0;
	socket_info info;
	struct sockaddr_in client_addr;
	int size = sizeof(client_addr);
	pthread_t tid;
	int ret;

	connect_fd = accept(listen_fd,(struct sockaddr *)(&client_addr),(socklen_t *)(&size));
	if(connect_fd <0)
	{
	    perror("Accept err");
	    continue;
	}   
	printf("connect ok\n");

	char str_helo[20] = {"CONFIRM_MSG:hello"};
	send(connect_fd,str_helo,20,0);

	info.socket_fd = connect_fd;
	info.ipaddr = inet_ntoa(client_addr.sin_addr);
	info.port = client_addr.sin_port;
	cli_num[cli_count] = info;
	cli_count++;

	ret = pthread_create(&tid,NULL,thread_receive,&info);
	if (ret != 0)
	{
	    perror("pthread");
	    close(connect_fd);
	    continue;
	}
	thread_num[thread_count] = tid;
	thread_count++;
	sleep(1);
    }
    pthread_exit(0);
}

int net_init(void)
{

	int listen_fd = -1;
	struct sockaddr_in server_addr;	
	int ret=0;

	listen_fd = socket(AF_INET,SOCK_STREAM,0);
	if(listen_fd < 0)
	{
	    perror("socket err");
	    return listen_fd;
	}

	memset(&server_addr,0,sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	ret = bind(listen_fd,(struct sockaddr *)&server_addr,sizeof(server_addr));
	if(ret<0 )
	{
	    perror("bind err");
	    close(listen_fd);
	    listen_fd = -1;
	    return listen_fd;
	}

	ret = listen(listen_fd,5);
	if(ret < 0 )
	{
	    close(listen_fd);
	    listen_fd = -1;
	    return listen_fd;
	}
	printf("init OK lsten...\n");
	return listen_fd; 
}


void daemon_create(void)
{
        pid_t pid=0;
	pid_t ret=0;
	//int i=0,num=0;
	
	pid=fork();	
	if (-1 == pid) 
	{    
	    perror("fork err");
	    return ;
	}    
	if (pid>0) 
	{
	    printf("pid=%d\n",pid);
	    exit(0); /*1 parent process exit*/
	}
	
	openlog(LOG_NAME,LOG_PID,LOG_DAEMON);
	    /* child (daemon) continues */
	ret = setsid(); /* obtain a new process group */
	if(ret < 0)
	{
	    //perror("setsid");
	    syslog(LOG_ERR,"%s\n","setside");
	    exit(1);
	}
	printf("deamon OK");
}
#if 0
	if(chdir(RUNNING_DIR)<0) /* change running directory */
	{
	    syslog(LOG_ERR,"%s\n","chdir");
	    exit(1);
	}
	umask(0); /* set newly created file permissions
	             Cancel any file permission block*/
	num = getdtablesize();
	for (;i<num;i--)
	{
	    close(i);
	}

#endif


