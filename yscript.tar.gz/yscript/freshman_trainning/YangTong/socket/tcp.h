#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <pthread.h>
#include <signal.h>

#define SERVER_IP "127.0.0.1"       // for lucal communication
// #define SERVER_IP "47.95.13.239" // for internet communication
#define SERVER_PORT     18888
#define RUNNING_DIR	"/tmp"
#define FILE_PATH       "./deamon1.txt"
#define LOG_NAME        "deamon1_syslog"



//Data information
typedef struct information
{
    int socket_fd;
    char * ipaddr;
    uint16_t port;
}socket_info;


#if 0
typedef struct data
{
    int type;
    long data1;
    char data2[30];
}data_info;
#endif
int read2send;
char buffer[30];
//
struct information cli_num[10];
int cli_count=0;
//
pthread_t thread_num[10];
int  thread_count=0;

   // number of threads

//function function
int check_thread(pthread_t thread);
void * thread_receive(void * info);
void * thread_accept(void * listen_fd);
void daemon_create(void);
int net_init(void);
char * strupr(char *str);


