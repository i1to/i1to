#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <pthread.h>
#include <signal.h>

#define SERVER_IP "127.0.0.1"       // for lucal communication
// #define SERVER_IP "47.95.13.239" // for internet communication
#define SERVER_PORT     18888
#define RUNNING_DIR	"/tmp"
#define FILE_PATH       "/tmp/deamon2.txt"
#define LOG_NAME        "deamon2_syslog"

void * thread_receive(void *fd);
void daemonize();

int main()
{
//	daemonize();	
	int socket_fd = -1;
	struct sockaddr_in server_addr;	
	int ret=0,len=0;
//	char str_recv[30] = {'0'};
	char str_send[30] = {'0'};
	pthread_t thread;

	socket_fd = socket(AF_INET,SOCK_STREAM,0);
	if(socket_fd < 0)
	{
	    perror("socket err");
	    exit(-1);
	}

	memset(&server_addr,0,sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);
	
	ret = connect(socket_fd,(struct sockaddr *)&server_addr,sizeof(struct sockaddr));
	if(ret < 0)
	{
	    perror("connect err");
	    return -1;    
	}
	printf("connect OK\n");

	pthread_create(&thread,NULL,thread_receive,&socket_fd);
	while(1)
	{
            scanf("%s",str_send);
            if(!strcmp(str_send,"quit"))
	    {
                printf("quit！\n");
                break;
	    }
	    len = send (socket_fd,str_send,strlen(str_send),0);
	    if(len > 0)
	    {
		printf("send ok:%d\n",socket_fd);
	    }
	    else
	    {
	        printf("send Err\n");
	    }	
	}	
	close(socket_fd);
	return 0;
}



void * thread_receive(void *fd)
{
    char str_recv[30] = {'0'};
    int socket_fd = *((int *)fd);
    int len = 0;
    while(1)
    {
        len = recv(socket_fd ,str_recv ,30,0);
        if(len > 0)
        {
	printf("recv :%s\n",str_recv);
        }
        sleep(1);
    }
    return NULL;
}





void daemonize()
{
        pid_t pid=0;
	pid_t ret=0;
//	int i=0,num=0;
	
	pid=fork();	
	if (-1 == pid) 
	{    
	    perror("fork err");
	    return ;
	}    
	if (pid>0) 
	{
	    printf("pid=%d\n",pid);
            exit(0); /*1 parent process exit*/
	}
	
	openlog(LOG_NAME,LOG_PID,LOG_DAEMON);
	    /* child (daemon) continues */
	ret = setsid(); /* obtain a new process group */
	if(ret < 0)
	{
	    perror("setsid");
	    syslog(LOG_ERR,"%s\n","setside");
	    exit(1);
	}

}
#if 0
	if(chdir(RUNNING_DIR)<0) /* change running directory */
	{
	    syslog(LOG_ERR,"%s\n","chdir");
	    exit(1);
	}
	umask(0); /* set newly created file permissions
	             Cancel any file permission block*/
	num = getdtablesize();
	for (;i<num;i--)
	{
	    close(i);
	}
}
#endif 
