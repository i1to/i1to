#include <stdlib.h>
#include <stdio.h>
#include "dblink.h"

link_head_t* create_dblink(void)
{
    link_head_t *pHead = NULL;
    pHead=(link_head_t *)malloc(sizeof(link_head_t));
    if(NULL==pHead)
    {
	perror("malloc error");
	return NULL;
    }
    pHead->head = NULL;
    pHead->last = NULL;
    return pHead;
}

int insert_dblink(link_head_t *pHead, void* data)
{
    link_node_t *pNew = NULL;

    if(NULL==pHead) 	
    {
	return -1;
    }

    pNew=(link_node_t *)malloc(sizeof(link_node_t));
    if(NULL==pNew)
    {
	perror("malloc error");
	return -1;
    }

    pNew->pre = NULL;
    pNew->next = NULL;
    pNew->data=data;
    if (pHead->head == NULL)
    {
	pHead->head = pNew;
	pHead->last = pNew;
    }
    else
    {
	pNew->pre = pHead->last;
	pHead->last->next = pNew;
	pHead->last = pNew;
    }

    return 0;
}

int search_dblink(link_head_t * pHead, void* data,int (*cmp)(void *data1,void *data2))
{
    if(NULL==pHead)
    {
	return -1;
    }

    link_node_t * pTem = NULL;
    pTem = pHead->head;

    while(NULL!=pTem)
    {
	if(cmp(pTem->data,data)==0)
	{
	    printf("found\n");
	    break;
	}
	pTem=pTem->next;
    }
    if(pTem==NULL)
    {
	printf("No data found!\n");
	return -1;
    }
    return 0;
}

int delete_dblink(link_head_t* pHead,void* data, int (*cmp)(void *data1, void *data2))
{
    link_node_t * pdel=NULL;
    if(NULL==pHead)
    {
	return -1;
    }
    pdel = pHead->head;
    while(NULL!=pdel)
    {
	if(cmp(pdel->data, data)==0)
	{
	    break;
	}
	pdel=pdel->next;
    }
    if(pdel==NULL)
    {
	return -1;
    }
    if(NULL!=pdel->pre && NULL!=pdel->next)
    {
	pdel->pre->next=pdel->next;
	pdel->next->pre=pdel->pre;
    }
    else if(NULL==pdel->pre && NULL!=pdel->next)
    {
	pHead->head=pdel->next;
	pdel->next->pre=NULL;
    }
    else if(NULL==pdel->next && NULL!=pdel->pre)
    {
	pdel->pre->next=NULL;
	pHead->last = pdel->pre;
    }
    else if(NULL==pdel->pre && NULL==pdel->next)
    {
	pHead->head = NULL;
	pHead->last = NULL;
    }
    return 0;
}

int show_dblink(link_head_t *pHead, void(*print)(void *data))
{
    link_node_t *pTem = NULL;
    if(NULL==pHead) 
    {
	return -1;
    }

    pTem = pHead->head;
    while(pTem != NULL)
    {
	(print)(pTem->data);
	pTem=pTem->next;
    }
    printf("\n");
    return 1;
}
