#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "dblink.h"
#include "util.h"
void print_int(void *data)
{
    int *tmp = (int *)data;
    printf("%d\n", *tmp);
}

void print_char(void *data)
{
    char *tmp = (char *)data;
    printf("%s\n", tmp);
}

int compare_int(void *data1, void *data2)
{
    int *a = (int *)data1;
    int *b = (int *)data2;
    return *a - *b;
}

int compare_char(void *data1,void *data2)
{
    char *a = (char *)data1;
    char *b = (char *)data2;
    int res = strcmp(a,b);
    return res;
}

int random_number()
{
    int i = 0;
    int *value = NULL;
    int aa=0;
    link_head_t* pHead = NULL;
    pHead = create_dblink();
    if (pHead == NULL)
    {
	return -1;
    }
    srand((unsigned)time(NULL));
    for (i = 0; i <= 9; i++)
    {
	value = malloc(sizeof(int));
	*value = rand()%10;
	//*value = i;
	insert_dblink(pHead, value);
	usleep(100);
    }
    show_dblink(pHead,print_int);
    while(1)
    {
	printf("Please enter the data you want to delete\n");
	printf("(Enter '-1' to end):");
	scanf("%d",&aa);
	if(-1==aa)
	{
	    break;
	}
	search_dblink(pHead,&aa,compare_int);
	delete_dblink(pHead,&aa,compare_int);
	printf("\nResult after delete:\n");
	show_dblink(pHead,print_int);

    }
    return 0;
}

int random_string()
{
    int i = 0;
    char *strvalue = NULL;
    char arr[64]={0};
    link_head_t* pHead = NULL;
    pHead = create_dblink();
    if (pHead == NULL)
    {
	return -1;
    }
    for(i=0; i<=9; i++)
    {
	strvalue = malloc(11);
	generate_string(strvalue,6);
	insert_dblink(pHead,strvalue);
    }
    show_dblink(pHead, print_char);
    while(1)
    {
	printf("Please enter the data you want to delete:\n");
	printf("(Enter 'exit' to end):");
	scanf("%s",arr);
	if(0==strcmp(arr,"exit"))
	{
	    break;
	}
	search_dblink(pHead, arr, compare_char);
	delete_dblink(pHead, arr, compare_char);
	printf("\nResult after delet:\n");
	show_dblink(pHead, print_char);
    }
    return 0;
}

int main()
{
    int option = 0;
    while(1)
    {
	printf("\n");
	printf("1----Generate 10 random numbers\n");
	printf("2----Generate 10 random strings\n");
	printf("-1----exit\n");
	printf("Please enter your option: ");
	scanf("%d",&option);
	if(option==-1)
	{
	    break;
	}
	switch(option)
	{
	    case 1:
		random_number();
		break;
	    case 2:
		random_string();
		break;
	    default:
		printf("Please enter the correct option!\n");
		break;
	}
    }
}
