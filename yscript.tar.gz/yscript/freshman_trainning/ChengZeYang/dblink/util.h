#ifndef _GENERATE_STRING_H_
#define _GENERATE_STRING_H_
void generate_string(unsigned char * dest, unsigned int len);
#endif /* _GENERATE_STRING_H_ */
