#ifndef _DBLINK_H
#define _DBLINK_H

typedef struct linknode
{
	struct linknode * pre; 
	struct linknode * next; 
	void * data;           
}link_node_t;

typedef struct linkhead
{
	struct linknode * head;
	struct linknode * last;
}link_head_t;

link_head_t * create_dblink(void);
int insert_dblink(link_head_t * pHead, void* data);
int search_dblink(link_head_t * pHead, void* data,int(*cmp)(void *data1,void *data2));
int show_dblink(link_head_t * pHead, void(*print)(void *data));
int delete_dblink(link_head_t * pHead,void* data, int (*cmp)(void *data1, void *data2));
#endif




