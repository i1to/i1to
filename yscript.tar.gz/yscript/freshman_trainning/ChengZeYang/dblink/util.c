#include <time.h>
#include <stdlib.h>

void generate_string(unsigned char * dest, const unsigned int len)
{
    const unsigned char allChar[63] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    unsigned int cnt, rand_no;
    static int count = 0;
    srand((unsigned int)time(NULL) + count++);

    for (cnt = 0; cnt<len; cnt++)
    {
	rand_no = rand() % 62;
	*dest = allChar[rand_no];
	dest++;
    }

    *dest = '\0';
}


