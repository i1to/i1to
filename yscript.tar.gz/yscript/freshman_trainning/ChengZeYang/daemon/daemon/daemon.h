#ifndef _DAEMON_H_
#define _DAEMON_H_

int creat_daemon();

#endif
