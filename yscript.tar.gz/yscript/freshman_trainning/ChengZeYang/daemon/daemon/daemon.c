#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <fcntl.h>
void handle(int num)
{
    pid_t recycle = wait(NULL);
    printf("recycle pid:%d\n",recycle);
}

int creat_daemon(void)
{
    signal(SIGINT,handle);
    int i = 2;
    pid_t pid = fork();
    if(pid == -1)
    {
	printf("fork error\n");
	return -1;
    }
    else if(pid > 0)
    {
	exit(0);
    }
    else
    {
	setsid();
	chdir("/");
	umask(0);

	while(i--)
	{
	    printf("pid:%d\n",getpid());
	    sleep(1);
	}
    }
    return 0;
}
