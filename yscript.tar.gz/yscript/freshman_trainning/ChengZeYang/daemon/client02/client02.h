#ifndef _CLIENT02_H_
#define _CLIENT02_H_

struct message
{
    int type;
    int length;
    char data[128];
};

char *get_randstr(char *buf,int len);
int send_str(int fd);


#endif
