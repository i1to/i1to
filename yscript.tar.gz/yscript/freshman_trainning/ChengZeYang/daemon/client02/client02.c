#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/time.h>
#include "client02.h"
#include "../daemon/daemon.h"

#define SERVER_PORT 10088
#define SERVER_IP "127.0.0.1"

char *get_randstr(char *buf,int len)
{
    int i = 0;
    struct timeval start;
    gettimeofday(&start,NULL);
    srand(start.tv_usec);
    char *str = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for(i=0;i<len-1;++i)
    {
	buf[i] = str[rand()%52];
    }
    buf[len-1] = '\0';

    return buf;

}

int send_str(int fd)
{
    struct message msg;
    msg.type = 2;
    get_randstr(msg.data,6);
    msg.length = 6;
    send(fd,&msg,sizeof(msg),0);
    return 0;
}

int main()
{
    //creat_daemon();
    int sock_fd = socket(PF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serv_addr = {0};
    int ret = 0;
    char connect_msg[8] = "CONNECT";
    char confirm_msg[8] = {0};
    struct message msg;

    if(sock_fd < 0)
    {
	perror("socket error!");
	return -1;
    }
    printf("socket ok!\n");

    memset(&serv_addr,0,sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    serv_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    ret = connect(sock_fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    if(ret < 0)
    {
	perror("connect error!");
	close(sock_fd);
	return -1;
    }
    printf("connect ok!\n");

    send(sock_fd,&connect_msg,sizeof(connect_msg),0);
    recv(sock_fd,&confirm_msg,sizeof(confirm_msg),0);
    printf("server :  %s\n",confirm_msg);

    while(1)
    {
	send_str(sock_fd);
	recv(sock_fd,&msg,sizeof(msg),0);
	printf("server response message : %s\n",msg.data);
	fflush(stdout);
	sleep(1);
    }

    close(sock_fd);
    return 0;
}


