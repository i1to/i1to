#ifndef _CLIENT01_H_
#define _CLIENT01_H_

struct message
{
    int type;
    int length;
    char data[128];
};

int send_int(int fd);

#endif
