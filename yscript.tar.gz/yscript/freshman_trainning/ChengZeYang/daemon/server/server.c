#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <string.h>
#include "../daemon/daemon.h"
#include "server.h"

#define SERVER_PORT 10088

char *uppercase_str(char *str)
{
    if(NULL == str)
    {
	return str;
    }
    while(*str != '\0')
    {
	if(*str >= 'a' && *str <= 'z')
	{
	    *str -= 32;
	}
	str++;
    }
    return str;
}

int main()
{
    creat_daemon();
    int listen_fd = 0;
    int conn_fd = 0;
    int ret = 0 ;
    struct sockaddr_in serv_addr = {0};
    struct sockaddr_in cli_addr = {0};
    struct message msg;
    char connect_msg[8] = {0};
    char confirm_msg[8] = "CONFIRM";
    int buf = 0;
    pthread_t thread_id;
    socklen_t len = sizeof(cli_addr);

    listen_fd = socket(PF_INET, SOCK_STREAM, 0);
    if(listen_fd < 0)
    {
	perror("socket error!");
	return -1;
    }	
    printf("socket ok!\n");
    
    memset(&serv_addr,0,sizeof(serv_addr));
    serv_addr.sin_family = PF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    ret = bind(listen_fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    if(ret < 0)
    {
	perror("bind error!");
	close(listen_fd);
	return -1;
    }
    printf("bind ok!\n");

    ret = listen(listen_fd, 10);
    if(ret < 0)
    {
	perror("listen error!");
	close(listen_fd);
	return -1;
    }
    printf("listening...\n");


    conn_fd = accept(listen_fd, (struct sockaddr *)&cli_addr, &len);
    if(conn_fd < 0)
    {
	perror("accept error!");
	close(listen_fd);
	return -1;
    }
    printf("accept ok!\n");
    printf("New client connect. IP:%s, PORT:%d\n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));


    recv(conn_fd, &connect_msg, sizeof(connect_msg), 0);
    printf("client : %s\n",connect_msg);
    send(conn_fd, &confirm_msg, sizeof(confirm_msg), 0); 
    while(1)
    {
	ret = recv(conn_fd, &msg, sizeof(msg), 0);
	if(ret < 0)
	{
	    perror("recv error!");
	    close(listen_fd);
	    close(conn_fd);
	    return -1;
	}
	else if(msg.type == 1)
	{
	    printf("client01 request message : %d\n",*msg.data);
	    buf = (*msg.data)*(*msg.data);
	    send(conn_fd,&buf,sizeof(buf),0);
	}
	else if(msg.type == 2)
	{
	    printf("client02 request message : %s\n",msg.data);
	    uppercase_str(msg.data);
	    send(conn_fd,&msg,sizeof(msg),0);
	}
	else
	{
	    return -1;
	}
    }
    close(listen_fd);
    close(conn_fd);
    return 0;
}


