#ifndef _SERVER_H_
#define _SERVER_H_

struct message 
{
    int type;
    int length;
    char data[128];
};

char *uppercase_str(char *str);
int creat_socket();
int do_client(int conn_fd);
#endif
